/* ============ icons ============ */
const P = {
  back:'M15 5l-7 7 7 7', chev:'M9 6l6 6-6 6', plus:'M12 5v14M5 12h14',
  bell:'M18 8a6 6 0 1 0-12 0c0 6-2 7-2 7h16s-2-1-2-7M13.7 20a2 2 0 0 1-3.4 0',
  search:'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16ZM21 21l-4.3-4.3',
  heart:'M20.8 6.6a5 5 0 0 0-7.1 0L12 8.3l-1.7-1.7a5 5 0 1 0-7.1 7.1l8.8 8.8 8.8-8.8a5 5 0 0 0 0-7.1Z',
  wallet:'M3 7.5A2.5 2.5 0 0 1 5.5 5H18a2 2 0 0 1 2 2v1M3 7.5V17a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-3M21 10v4h-4a2 2 0 1 1 0-4h4Z',
  pin:'M12 21s7-5.6 7-11a7 7 0 1 0-14 0c0 5.4 7 11 7 11Z',
  book:'M4 4.5A2.5 2.5 0 0 1 6.5 2H20v16H6.5A2.5 2.5 0 0 0 4 20.5V4.5ZM4 20.5A2.5 2.5 0 0 1 6.5 18H20v4H6.5A2.5 2.5 0 0 1 4 19.5Z',
  chat:'M21 11.5a8.4 8.4 0 0 1-9 8.4 9 9 0 0 1-3.9-.9L3 20.5l1.6-4.6A8.4 8.4 0 0 1 12 3.1a8.4 8.4 0 0 1 9 8.4Z',
  spark:'M12 3l1.9 5.3L19 10l-5.1 1.7L12 17l-1.9-5.3L5 10l5.1-1.7L12 3Z',
  lock:'M6 10V8a6 6 0 1 1 12 0v2M5 10h14v11H5V10Z', eye:'M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Zm10 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z',
  eyeoff:'M3 3l18 18M10.6 10.7a3 3 0 0 0 4.2 4.2M9.4 5.4A9.7 9.7 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4M6.2 6.6A16.6 16.6 0 0 0 2 12s3.6 7 10 7a9.9 9.9 0 0 0 4-.8',
  check:'M4 12.5 9.5 18 20 6.5', user:'M12 12a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9ZM3.5 21a8.5 8.5 0 0 1 17 0',
  shield:'M12 2.5 20 6v6c0 5-3.4 8.4-8 9.5C7.4 20.4 4 17 4 12V6l8-3.5Z',
  phone:'M21 16.9v2.6a2 2 0 0 1-2.2 2 19.4 19.4 0 0 1-8.5-3 19 19 0 0 1-5.9-5.9 19.4 19.4 0 0 1-3-8.6A2 2 0 0 1 3.4 2H6a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L7.1 9.9a15 15 0 0 0 5.8 5.8l1.2-1.2a2 2 0 0 1 2.1-.4c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.9 2.1Z',
  video:'M3 7.5A2.5 2.5 0 0 1 5.5 5h8A2.5 2.5 0 0 1 16 7.5v9a2.5 2.5 0 0 1-2.5 2.5h-8A2.5 2.5 0 0 1 3 16.5v-9ZM16 10.5l5-3v9l-5-3',
  send:'M21.5 2.5 2.5 11l7.5 2.5L13 21l8.5-18.5ZM10 13.5 21.5 2.5',
  mic:'M12 15a3.5 3.5 0 0 0 3.5-3.5V6a3.5 3.5 0 1 0-7 0v5.5A3.5 3.5 0 0 0 12 15ZM5 11.5a7 7 0 0 0 14 0M12 15v6',
  cam:'M3 8.5A2.5 2.5 0 0 1 5.5 6h2L9 4h6l1.5 2h2A2.5 2.5 0 0 1 21 8.5v9A2.5 2.5 0 0 1 18.5 20h-13A2.5 2.5 0 0 1 3 17.5v-9ZM12 16.5a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z',
  cal:'M4 7.5A2.5 2.5 0 0 1 6.5 5h11A2.5 2.5 0 0 1 20 7.5v11a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 18.5v-11ZM4 10h16M8.5 3v4M15.5 3v4',
  wind:'M3 8h11a3 3 0 1 0-3-3M3 12h15a3 3 0 1 1-3 3M3 16h8a2.5 2.5 0 1 1-2.5 2.5',
  chart:'M4 20V10M10 20V4M16 20v-7M22 20H2',
  cog:'M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4ZM19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1v.3a2 2 0 1 1-4 0v-.2a1.6 1.6 0 0 0-2.8-1.1l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.6 1.6 0 0 0 3.5 14H3a2 2 0 1 1 0-4h.2A1.6 1.6 0 0 0 4.3 7.2l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.6 1.6 0 0 0 9.9 3.5V3a2 2 0 1 1 4 0v.2a1.6 1.6 0 0 0 2.7 1.1l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0 1.1 2.7h.3a2 2 0 1 1 0 4h-.2a1.6 1.6 0 0 0-1.2 1.2Z',
  help:'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM9.5 9.2a2.6 2.6 0 1 1 3.4 2.5c-.6.2-.9.8-.9 1.4v.4M12 17h.01',
  logout:'M15 17l5-5-5-5M20 12H9M11 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h5',
  device:'M6 3.5A2.5 2.5 0 0 1 8.5 1h7A2.5 2.5 0 0 1 18 3.5v17a2.5 2.5 0 0 1-2.5 2.5h-7A2.5 2.5 0 0 1 6 20.5v-17ZM10.5 19.5h3',
  trash:'M4 7h16M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2M6 7l1 13h10l1-13',
  share:'M12 16V3m0 0L7.5 7.5M12 3l4.5 4.5M4 14v5a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5',
  image:'M3 6.5A2.5 2.5 0 0 1 5.5 4h13A2.5 2.5 0 0 1 21 6.5v11a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5v-11ZM3 16l5-5 4 4 3-3 6 6M8.5 9.5a1.2 1.2 0 1 0 0-2.4 1.2 1.2 0 0 0 0 2.4Z',
  paint:'M12 21a9 9 0 1 1 9-9c0 2-1.6 2.6-3 2.6h-1.6a2 2 0 0 0-1.4 3.4 2 2 0 0 1-1.4 3.4 6 6 0 0 1-.6 0Z',
  users:'M16 20v-1.8a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4V20M9 10.5a3.8 3.8 0 1 0 0-7.5 3.8 3.8 0 0 0 0 7.5ZM22 20v-1.8a4 4 0 0 0-3-3.8M16 3.2a4 4 0 0 1 0 7.5',
  nav:'M12 2 20 21l-8-4.5L4 21 12 2Z', clock:'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 7v5.2l3.4 2',
  alert:'M12 8.5v4.5M12 16.5h.01M10.3 3.9 2.6 17.5A2 2 0 0 0 4.3 20.5h15.4a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z',
  poll:'M6 20V13M12 20V7M18 20v-4', grid:'M4 4h7v7H4V4ZM13 4h7v7h-7V4ZM4 13h7v7H4v-7ZM13 13h7v7h-7v-7Z',
  flag:'M5 21V4h13l-2.5 4L18 12H5', star:'M12 3.5l2.6 5.6 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.9l6-.8L12 3.5Z',
  mood:'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM8.5 14.5a4.5 4.5 0 0 0 7 0M9 9.5h.01M15 9.5h.01',
  gift:'M4 11h16v9H4v-9ZM2 7h20v4H2V7ZM12 7v13M12 7S9.5 2.5 7 4s1.5 3 5 3Zm0 0s2.5-4.5 5-3-1.5 3-5 3Z',
  mail:'M3 6.5A2 2 0 0 1 5 4.5h14a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-11ZM3 6.5l9 7 9-7',
  fingerprint:'M12 3a9 9 0 0 0-9 9v3M12 3a9 9 0 0 1 9 9v3M8 21v-4a4 4 0 1 1 8 0v4M12 21v-6a1 1 0 1 0-2 0v3'
};
const ic = (n,c='currentColor',s=20,w=1.9)=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round"><path d="${P[n]}"/></svg>`;

/* ============ helpers ============ */
const S = {};
const reg = (id,group,label,fn)=>{ S[id]={id,group,label,render:fn}; };
let stack=['splash'];
const $ = s=>document.querySelector(s);
function mesh(){ return `<div class="mesh"></div>`; }
function statusbar(){
  const c='currentColor';
  return `<div class="statusbar">
    <span>9:41</span>
    <span class="r">
      <svg width="17" height="12" viewBox="0 0 17 12" fill="${c}"><rect x="0" y="8" width="3" height="4" rx="1"/><rect x="4.5" y="5.5" width="3" height="6.5" rx="1"/><rect x="9" y="3" width="3" height="9" rx="1"/><rect x="13.5" y="0" width="3" height="12" rx="1"/></svg>
      <svg width="16" height="12" viewBox="0 0 16 12" fill="${c}"><path d="M8 11.2 6 8.9a3 3 0 0 1 4 0l-2 2.3ZM8 6.4a5.6 5.6 0 0 0-4 1.6L2.6 6.6a7.6 7.6 0 0 1 10.8 0L12 8a5.6 5.6 0 0 0-4-1.6ZM8 2.2a9.8 9.8 0 0 0-6.9 2.8L0 3.7A11.8 11.8 0 0 1 16 3.7L14.9 5A9.8 9.8 0 0 0 8 2.2Z"/></svg>
      <svg width="26" height="12" viewBox="0 0 26 12" fill="none"><rect x=".6" y=".6" width="21" height="10.8" rx="3.2" stroke="${c}" stroke-opacity=".4"/><rect x="2.4" y="2.4" width="15" height="7.2" rx="2" fill="${c}"/><path d="M23.4 4.2v3.6a2 2 0 0 0 0-3.6Z" fill="${c}" fill-opacity=".4"/></svg>
    </span>
  </div>`;
}
function nav(title,{back=null,right='',sub=''}={}){
  return `<div class="navbar">
    ${back?`<button class="iconbtn" onclick="back()">${ic('back','currentColor',19)}</button>`:''}
    <div style="flex:1;min-width:0"><h2>${title}</h2>${sub?`<p class="p" style="font-size:12px;margin-top:2px">${sub}</p>`:''}</div>
    ${right}
  </div>`;
}
const TABS=[['stress','Stress Buster','heart','#FF6E7F'],['money','Money Guard','wallet','#FFB84D'],['track','Track Friends','pin','#35E1C8'],['diary','My Diary','book','#7C5CFC'],['chats','Chats','chat','#9B7BFF']];
function tabbar(active){
  return `<div class="tabbar">${TABS.map(([id,l,i,c])=>`
    <button class="tab ${active===id?'on':''}" onclick="go('${id}')">
      <span class="ic-wrap" style="${active===id?`background:linear-gradient(135deg,${c},#7C5CFC)`:''}">${ic(i,'currentColor',18,active===id?2.3:1.8)}</span>
      <span>${l.split(' ')[0]}</span>
    </button>`).join('')}</div>`;
}
const av=(initials,color,size=40,fs=14)=>`<div class="avatar" style="width:${size}px;height:${size}px;background:${color};font-size:${fs}px">${initials}</div>`;

function toast(msg,icon='check',color='#35E1C8'){
  const t=document.createElement('div'); t.className='toast';
  t.innerHTML=`<div class="sqico" style="background:${color};flex:0 0 28px;width:28px;height:28px;border-radius:10px">${ic(icon,'#0A0E1E',15,2.4)}</div><div style="font-size:13.5px;font-weight:600;line-height:1.4">${msg}</div>`;
  $('#screen').appendChild(t); setTimeout(()=>{t.style.transition='.3s';t.style.opacity=0;t.style.transform='translateY(-60px)';setTimeout(()=>t.remove(),320)},2400);
}
function overlay(html){ const w=document.createElement('div'); w.id='ov'; w.innerHTML=`<div class="scrim" onclick="closeOv()"></div>${html}`; $('#screen').appendChild(w); }
function closeOv(){ const o=$('#ov'); if(o) o.remove(); }
function sheet(html){ overlay(`<div class="sheet"><div class="grab"></div>${html}</div>`); }
function modal(html){ overlay(`<div class="modal">${html}</div>`); }
function go(id,replace){ closeOv(); if(replace) stack[stack.length-1]=id; else stack.push(id); paint('anim'); }
function back(){ closeOv(); if(stack.length>1) stack.pop(); paint('anim-back'); }
function paint(anim=''){
  const id=stack[stack.length-1], sc=S[id]||S.dashboard;
  $('#screen').innerHTML=`<div class="view ${anim}">${sc.render()}</div>`;
  document.querySelectorAll('#rail a').forEach(a=>a.classList.toggle('on',a.dataset.id===id));
  const el=document.querySelector('#rail a.on'); if(el) el.scrollIntoView({block:'nearest'});
}
function setTheme(t){ document.documentElement.dataset.theme=t; $('#tDark').classList.toggle('on',t==='dark'); $('#tLight').classList.toggle('on',t==='light'); }
function tog(el){ el.classList.toggle('on'); }
function chk(row){
  const b=row.querySelector('.chk'), on=!b.classList.contains('yes');
  b.classList.toggle('yes',on);
  b.style.background=on?'linear-gradient(135deg,#7C5CFC,#35E1C8)':'transparent';
  b.style.borderColor=on?'transparent':'var(--border)';
  b.innerHTML=on?ic('check','#fff',13,3.2):'';
}
function togglePw(btn){
  const f=btn.closest('.field').querySelector('input'); const on=f.type==='password';
  f.type=on?'text':'password'; btn.innerHTML=ic(on?'eyeoff':'eye','var(--muted)',18);
}
function strength(el){
  const v=el.value, score=[/[A-Z]/,/[a-z]/,/\d/,/[^\w]/].filter(r=>r.test(v)).length + (v.length>9?1:0);
  const lv=Math.min(4,score), cols=['#FF4D5E','#FF6E7F','#FFB84D','#35E1C8','#35E1C8'], txt=['Too short','Weak','Okay','Strong','Strong'];
  for(let i=0;i<4;i++) document.getElementById('sb'+i).style.background = i<lv?cols[lv]:'var(--glass2)';
  const l=document.getElementById('sLabel'); l.textContent=txt[lv]; l.style.color=cols[lv];
}
function otpNext(el,i){
  if(el.value.length===1 && i<5) document.getElementById('otp'+(i+1)).focus();
  const all=[0,1,2,3,4,5].every(n=>document.getElementById('otp'+n).value.length);
  if(all){ toast('Email verified. Welcome to NEXORA.'); setTimeout(()=>go('login',true),750); }
}
function txnAdded(){ toast('Transaction added.'); }
function goalAdded(){ toast('₹500 added. 93% of the goal is funded.'); }
function confirmDeleteEntry(){
  closeOv();
  modal(`<div class="h3">Delete this entry?</div>
    <p class="p" style="margin:8px 0 18px">"Golden hour on the quad" and its photo will be permanently removed. This can't be undone.</p>
    <button class="btn danger" onclick="closeOv();toast('Entry deleted.','trash','#FF6E7F');back()">Delete entry</button>
    <button class="btn sec" style="margin-top:8px" onclick="closeOv()">Keep it</button>`);
}
function endTrackConfirm(){
  closeOv();
  modal(`<div class="h3">End this track?</div>
    <p class="p" style="margin:8px 0 18px">Everyone stops seeing your location right away. The session can't be restarted.</p>
    <button class="btn danger" onclick="closeOv();go('track')">End track</button>
    <button class="btn sec" style="margin-top:8px" onclick="closeOv()">Keep tracking</button>`);
}
function signOutAllConfirm(){
  closeOv();
  modal(`<div class="h3">Sign out everywhere else?</div>
    <p class="p" style="margin:8px 0 18px">Two other sessions end immediately. You stay signed in on this iPhone.</p>
    <button class="btn danger" onclick="closeOv();toast('All other sessions ended.')">Sign out all</button>
    <button class="btn sec" style="margin-top:8px" onclick="closeOv()">Cancel</button>`);
}
function deleteAccountConfirm(){
  closeOv();
  modal(`<div class="h3">Delete your NEXORA account?</div>
    <p class="p" style="margin:8px 0 18px">Diary pages, moods, plans and chats are removed within 30 days. This can't be undone.</p>
    <button class="btn danger" onclick="closeOv()">Delete everything</button>
    <button class="btn sec" style="margin-top:8px" onclick="closeOv()">Cancel</button>`);
}
function logoutConfirm(){
  closeOv();
  modal(`<div class="h3">Log out of NEXORA?</div>
    <p class="p" style="margin:8px 0 18px">Your diary stays private on this device. Face ID or your password gets you back in.</p>
    <button class="btn danger" onclick="closeOv();stack=['welcome'];paint('anim-back')">Log out</button>
    <button class="btn sec" style="margin-top:8px" onclick="closeOv()">Stay signed in</button>`);
}

/* =================== 1. Splash =================== */
reg('splash','Onboarding','Splash Screen',()=>`
<div style="position:absolute;inset:0;background:radial-gradient(120% 90% at 30% 0%,#241B57,#0A0E1E 60%);display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff" onclick="go('welcome',true)">
  ${statusbar()}
  <div style="position:absolute;inset:0;overflow:hidden">
    <div style="position:absolute;width:60px;height:60px;border-radius:16px;border:1px solid rgba(255,255,255,.14);top:120px;left:36px;transform:rotate(18deg)"></div>
    <div style="position:absolute;width:40px;height:40px;border-radius:12px;border:1px solid rgba(255,255,255,.12);bottom:170px;right:40px;transform:rotate(-12deg)"></div>
    <div style="position:absolute;width:420px;height:420px;border-radius:50%;background:radial-gradient(circle,rgba(124,92,252,.25),transparent 70%);top:-160px;right:-140px"></div>
  </div>
  <div style="position:relative;text-align:center">
    <div style="width:88px;height:88px;border-radius:26px;margin:0 auto 22px;background:linear-gradient(135deg,#7C5CFC,#35E1C8);display:grid;place-items:center;box-shadow:0 26px 54px -20px rgba(124,92,252,.85);animation:pin .7s cubic-bezier(.32,.72,0,1)">
      <svg width="42" height="42" viewBox="0 0 24 24" fill="none"><path d="M4 4h4l8 12V4h4v16h-4L8 8v12H4V4Z" fill="#fff"/></svg>
    </div>
    <div style="font-family:var(--disp);font-size:40px;font-weight:700;letter-spacing:-.01em">NEXORA</div>
    <p style="font-size:13.5px;opacity:.72;margin:12px 0 0;font-weight:500;max-width:250px">Your space. Your people. Your everyday companion.</p>
  </div>
  <div style="position:absolute;bottom:74px;display:flex;flex-direction:column;align-items:center;gap:12px">
    <div style="width:150px;height:3px;border-radius:3px;background:rgba(255,255,255,.18);overflow:hidden"><div style="height:100%;background:linear-gradient(90deg,#7C5CFC,#35E1C8);animation:load 1.9s cubic-bezier(.4,0,.2,1) forwards"></div></div>
    <p style="font-size:11px;opacity:.6;margin:0">Tap to continue</p>
  </div>
  <style>@keyframes load{from{width:4%}to{width:100%}}</style>
</div>`);

/* =================== 2. Welcome =================== */
reg('welcome','Onboarding','Welcome Screen',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body" style="display:flex;flex-direction:column">
    <div style="flex:1;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;padding:6px 4px 24px">
      <div style="position:relative;width:230px;height:230px;margin-bottom:4px">
        ${[['heart','#FF6E7F',10,26],['wallet','#FFB84D',168,4],['pin','#35E1C8',180,140],['book','#9B7BFF',18,152],['chat','#7C5CFC',94,190]].map(([i,c,x,y],n)=>
          `<div style="position:absolute;left:${x}px;top:${y}px;width:52px;height:52px;border-radius:17px;background:var(--glass);border:1px solid var(--border);backdrop-filter:var(--blur);display:grid;place-items:center;animation:pin .5s ${0.1*n+0.1}s backwards cubic-bezier(.32,.72,0,1)">${ic(i,c,22,2.1)}</div>`).join('')}
        <div style="position:absolute;left:73px;top:73px;width:84px;height:84px;border-radius:28px;background:linear-gradient(135deg,#7C5CFC,#35E1C8);display:grid;place-items:center;box-shadow:0 24px 48px -18px rgba(124,92,252,.85)">
          <svg width="38" height="38" viewBox="0 0 24 24" fill="none"><path d="M4 4h4l8 12V4h4v16h-4L8 8v12H4V4Z" fill="#fff"/></svg>
        </div>
      </div>
      <h1 style="font-family:var(--disp);font-size:34px;letter-spacing:-.015em;margin:12px 0 0;line-height:1.1;font-weight:700">Welcome to NEXORA</h1>
      <p class="p" style="max-width:290px;margin-top:12px;font-size:14.5px">One intelligent, secure space for your everyday life, emotions, money, memories and friendships.</p>
    </div>
    <div class="stack" style="padding-bottom:10px">
      <button class="btn" onclick="go('signup')">Create account</button>
      <button class="btn line" onclick="go('login')">I already have an account</button>
      <p class="p" style="text-align:center;font-size:11.5px;margin-top:4px">By continuing you agree to our Terms and Privacy Notice.</p>
    </div>
  </div>
</div>`);

/* =================== 3. Sign up =================== */
reg('signup','Onboarding','Sign Up',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Create your account',{back:true,sub:'NEXORA is better with real students only.'})}
    <div class="stack">
      <div class="field"><div class="col"><label>Email ID</label><input type="email" value="alex.m@college.edu"></div>${ic('mail','var(--muted)',18)}</div>
      <div class="field"><div class="col"><label>Create password</label><input type="password" value="Northstar#26" oninput="strength(this)"></div><button class="iconbtn ghost" onclick="togglePw(this)">${ic('eye','var(--muted)',18)}</button></div>
      <div class="glass tight" style="background:var(--glass2)">
        <div class="between" style="margin-bottom:9px"><span style="font-size:12px;font-weight:700">Password strength</span><span id="sLabel" style="font-size:12px;font-weight:800;color:#35E1C8">Strong</span></div>
        <div style="display:flex;gap:5px">${[0,1,2,3].map(i=>`<div id="sb${i}" style="flex:1;height:5px;border-radius:5px;background:#35E1C8"></div>`).join('')}</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:12px">
          ${['Uppercase letter','Lowercase letter','Number','Special character'].map(t=>
          `<div class="row" style="gap:7px"><div style="width:17px;height:17px;border-radius:50%;background:#35E1C8;display:grid;place-items:center">${ic('check','#04241D',11,3)}</div><span style="font-size:11.5px;color:var(--muted);font-weight:600">${t}</span></div>`).join('')}
        </div>
      </div>
      <div class="field"><div class="col"><label>Confirm password</label><input type="password" value="Northstar#26"></div><span class="pill cyan">Matches</span></div>
      <div class="glass tight row" style="align-items:flex-start;gap:11px">
        <div class="switch on" onclick="tog(this)" style="margin-top:2px"></div>
        <p class="p" style="font-size:12.5px;color:var(--text)">I agree to the <b style="color:var(--violet)">Terms</b> and <b style="color:var(--violet)">Privacy Notice</b>. My diary, mood and location stay private unless I choose to share them.</p>
      </div>
      <button class="btn" onclick="go('verify')">Create account</button>
      <p class="p" style="text-align:center;font-size:12.5px">Already have an account? <b style="color:var(--violet)" onclick="go('login')">Log in</b></p>
    </div>
  </div>
</div>`);

/* =================== 4. Email verification =================== */
reg('verify','Onboarding','Email Verification',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body" style="text-align:center">
    ${nav('',{back:true})}
    <div style="width:74px;height:74px;border-radius:24px;background:rgba(124,92,252,.16);border:1px solid var(--border);display:grid;place-items:center;margin:6px auto 18px">${ic('mail','var(--violet)',32,2)}</div>
    <h2 style="font-family:var(--disp);font-size:24px;letter-spacing:-.015em;margin:0;font-weight:700">Check your inbox</h2>
    <p class="p" style="margin:10px 0 24px">We sent a 6-digit code to <b style="color:var(--text)">alex.m@college.edu</b>. Enter it below to verify your account.</p>
    <div class="otp">${[0,1,2,3,4,5].map(i=>`<input id="otp${i}" maxlength="1" inputmode="numeric" value="${i<3?['7','4','2'][i]:''}" oninput="otpNext(this,${i})">`).join('')}</div>
    <p class="p" style="margin-top:18px;font-size:12px">Didn't get it? <b style="color:var(--violet)" onclick="toast('Code resent.','mail','#7C5CFC')">Resend in 0:42</b></p>
    <div class="glass tight" style="margin-top:26px;text-align:left">
      <div class="row" style="gap:10px;align-items:flex-start">${ic('shield','var(--cyan)',17,2.2)}<p class="p" style="font-size:12px">This code expires in 10 minutes. NEXORA support will never ask you to share it.</p></div>
    </div>
  </div>
</div>`);

/* =================== 5. Login =================== */
reg('login','Onboarding','Login',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Welcome back',{back:true,sub:'Log in to your everyday companion.'})}
    <div class="stack">
      <div class="field"><div class="col"><label>Email ID</label><input type="email" value="alex.m@college.edu"></div>${ic('mail','var(--muted)',18)}</div>
      <div class="field"><div class="col"><label>Password</label><input type="password" value="Northstar#26"></div><button class="iconbtn ghost" onclick="togglePw(this)">${ic('eye','var(--muted)',18)}</button></div>
      <div class="between">
        <div class="row" style="gap:9px"><div class="switch on" onclick="tog(this)"></div><span style="font-size:12.5px;font-weight:700">Remember me</span></div>
        <span style="font-size:12.5px;font-weight:700;color:var(--violet)" onclick="go('forgot')">Forgot password?</span>
      </div>
      <button class="btn" onclick="go('newlogin',true)">Secure login</button>
      <button class="btn sec" onclick="toast('Face ID confirmed.','fingerprint','#35E1C8');setTimeout(()=>go('newlogin',true),650)">${ic('fingerprint','currentColor',19)} Use Face ID</button>
      <div class="hairline" style="margin:6px 0"></div>
      <button class="btn line" onclick="go('help')">${ic('help','currentColor',18)} Having trouble logging in?</button>
    </div>
  </div>
</div>`);

/* =================== 5b. Forgot password =================== */
reg('forgot','Onboarding','Forgot Password',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Reset password',{back:true})}
    <div class="glass" style="background:linear-gradient(135deg,rgba(124,92,252,.9),rgba(53,225,200,.65));color:#fff;border:0">
      <div class="sqico" style="background:rgba(255,255,255,.22);margin-bottom:12px">${ic('lock','#fff',18,2.2)}</div>
      <div style="font-family:var(--disp);font-size:19px;font-weight:700">We'll email you a reset link</div>
      <p style="font-size:13px;opacity:.9;line-height:1.55;margin:8px 0 0">The link works once and expires in 15 minutes. No one, including NEXORA support, can see your current password.</p>
    </div>
    <div class="stack" style="margin-top:14px">
      <div class="field"><div class="col"><label>Email on your account</label><input type="email" value="alex.m@college.edu"></div></div>
      <button class="btn" onclick="modal('<div class=&quot;h3&quot;>Check your inbox</div><p class=&quot;p&quot; style=&quot;margin:10px 0 18px&quot;>A reset link is on its way to alex.m@college.edu.</p><button class=&quot;btn&quot; onclick=&quot;closeOv();back()&quot;>Back to login</button>')">Send reset link</button>
    </div>
  </div>
</div>`);

/* =================== 6. New login alert =================== */
reg('newlogin','Onboarding','New Login Alert',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    <div style="padding:14px 0 18px;text-align:center">
      <div style="width:66px;height:66px;border-radius:22px;background:rgba(255,184,77,.16);border:1px solid var(--border);display:grid;place-items:center;margin:0 auto 14px;animation:pin .45s cubic-bezier(.32,.72,0,1)">${ic('shield','#FFB84D',30,2.1)}</div>
      <h2 style="font-family:var(--disp);font-size:24px;letter-spacing:-.015em;margin:0;font-weight:700">New sign-in detected</h2>
      <p class="p" style="margin-top:8px;padding:0 16px">Your account was just accessed from a device we haven't seen before. A security alert was also sent to your email.</p>
    </div>
    <div class="glass">
      ${[['Device','iPhone 15 Pro · iOS 18.4','device'],['Approximate location','Chennai, Tamil Nadu (city-level only)','pin'],['Time','Today at 9:41 AM','clock']].map(([k,v,i],n)=>
      `<div class="row" style="padding:${n?'13px':'0'} 0 ${n===2?'0':'13px'};gap:12px;${n?'border-top:1px solid var(--hair)':''}">
        <div class="sqico" style="background:var(--glass2)">${ic(i,'var(--muted)',16)}</div>
        <div style="flex:1"><div style="font-size:11.5px;color:var(--muted);font-weight:600">${k}</div><div style="font-size:13.5px;font-weight:700;margin-top:1px">${v}</div></div>
      </div>`).join('')}
    </div>
    <div class="stack" style="margin-top:14px">
      <button class="btn" onclick="toast('Device trusted. Welcome to NEXORA.');setTimeout(()=>go('help',true),700)">This was me</button>
      <button class="btn line" onclick="go('devices')">Review login</button>
      <button class="btn sec" onclick="go('security')">Secure my account</button>
    </div>
    <p class="p" style="text-align:center;font-size:11.5px;margin-top:14px">Location is approximate and only visible to you. NEXORA never exposes your password to anyone.</p>
  </div>
</div>`);

/* =================== 7. Help & support (post-login) =================== */
reg('help','Onboarding','Help & Support Screen',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Is there anything you need help with?',{right:`<button class="pill" style="font-size:11.5px" onclick="go('dashboard',true)">Skip</button>`})}
    <div class="grid2">
      ${[['Login problem','lock','#7C5CFC'],['Account problem','user','#9B7BFF'],['Privacy & security','shield','#35E1C8'],['Payment problem','wallet','#FFB84D'],['Location problem','pin','#FF6E7F'],['Chat problem','chat','#7C5CFC'],['Report an issue','alert','#FF6E7F'],['AI Help','spark','#35E1C8']].map(([t,i,c])=>
      `<button class="glass tight" style="text-align:left" onclick="toast('Opening ${t.toLowerCase()} support…','${i}','${c}')">
        <div class="sqico" style="background:${c}26">${ic(i,c,17,2.1)}</div>
        <div style="font-size:13px;font-weight:800;margin-top:10px;letter-spacing:-.005em">${t}</div>
      </button>`).join('')}
    </div>
    <button class="btn" style="margin-top:16px" onclick="go('dashboard',true)">Take me to my dashboard</button>
  </div>
</div>`);

/* =================== 8. Dashboard =================== */
reg('dashboard','Home & AI','Personalized Dashboard',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body tabbed">
    <div class="between" style="padding:2px 0 16px">
      <div class="row">
        <div onclick="go('profile')">${av('A','linear-gradient(135deg,#7C5CFC,#35E1C8)',44,17)}</div>
        <div><p class="eyebrow" style="font-size:12px">Good evening,</p><div style="font-family:var(--disp);font-size:20px;letter-spacing:-.01em;line-height:1.1;font-weight:700">Alex 👋</div></div>
      </div>
      <button class="iconbtn" onclick="go('notifs')" style="position:relative">${ic('bell','currentColor',19)}<span style="position:absolute;top:6px;right:7px;width:8px;height:8px;border-radius:8px;background:#FF6E7F;border:2px solid var(--bg)"></span></button>
    </div>
    <p class="p" style="font-size:12.5px;margin:0 2px 14px;font-style:italic">Ready for a better day? Small steps count more than perfect ones.</p>

    <div class="glass" onclick="go('ai')" style="background:linear-gradient(135deg,rgba(124,92,252,.9),rgba(53,225,200,.6));border:0;padding:18px;box-shadow:var(--glow-v);cursor:pointer;color:#fff">
      <div class="row" style="gap:10px;margin-bottom:13px">
        <div style="width:26px;height:26px;border-radius:9px;background:rgba(255,255,255,.22);display:grid;place-items:center">${ic('spark','#fff',15,2.2)}</div>
        <span style="font-size:12.5px;font-weight:700;opacity:.92">NEXORA AI</span>
        <span style="margin-left:auto;font-size:10.5px;font-weight:700;background:rgba(255,255,255,.2);padding:4px 9px;border-radius:999px">Context-aware</span>
      </div>
      <div style="background:rgba(255,255,255,.18);border-radius:15px;padding:13px 14px;display:flex;align-items:center;gap:10px">
        <span style="font-size:14.5px;font-weight:600;opacity:.85;flex:1">Ask NEXORA anything…</span>${ic('mic','#fff',18)}
      </div>
      <div style="display:flex;gap:7px;margin-top:11px;overflow:hidden">
        ${['Plan my day','I\'m feeling stressed','Where\'s Priya?'].map(t=>`<span style="font-size:11px;font-weight:700;padding:6px 11px;border-radius:999px;background:rgba(255,255,255,.16);white-space:nowrap">${t}</span>`).join('')}
      </div>
    </div>

    <div class="grid2" style="margin-top:14px">
      <div class="glass tight" onclick="go('quickactions')" style="cursor:pointer">
        <p class="eyebrow">Quick actions</p>
        <div class="row" style="gap:8px;margin-top:10px">${ic('cal','var(--violet)',18,2.1)}<div><div style="font-size:12.5px;font-weight:700">3 today</div></div></div>
      </div>
      <div class="glass tight" onclick="go('money')" style="cursor:pointer">
        <div class="between"><p class="eyebrow">Money left</p><span class="pill amber">Demo</span></div>
        <div class="big" style="font-size:20px;margin-top:6px">₹3,240</div>
      </div>
    </div>

    <div class="glass" style="margin-top:12px" onclick="go('track')">
      <div class="between" style="margin-bottom:12px"><p class="eyebrow">Friend status</p><span class="pill cyan">2 sharing</span></div>
      <div class="row" style="gap:12px">
        <div style="display:flex">${[['P','#35E1C8'],['J','#FFB84D'],['R','#FF6E7F']].map(([i,c],n)=>`<div style="margin-left:${n?'-12px':'0'};border:2.5px solid var(--bg);border-radius:50%">${av(i,c,36,13)}</div>`).join('')}</div>
        <div style="flex:1"><div style="font-size:13.5px;font-weight:700">Priya is 400 m away</div><p class="p" style="font-size:11.5px">Library block · updated 1 min ago</p></div>${ic('chev','var(--muted)',17)}
      </div>
    </div>

    <div class="grid2" style="margin-top:12px">
      <div class="glass tight">
        <p class="eyebrow">Upcoming</p>
        <div class="row" style="gap:9px;margin-top:9px"><div class="sqico" style="background:rgba(124,92,252,.18);width:30px;height:30px;flex:0 0 30px">${ic('cal','var(--violet)',15,2.2)}</div><div><div style="font-size:12.5px;font-weight:700;line-height:1.25">CS Lab</div><div style="font-size:11px;color:var(--muted)">2:00 PM</div></div></div>
        <div class="row" style="gap:9px;margin-top:11px"><div class="sqico" style="background:rgba(255,110,127,.16);width:30px;height:30px;flex:0 0 30px">${ic('users','var(--coral)',15,2.2)}</div><div><div style="font-size:12.5px;font-weight:700;line-height:1.25">Movie night</div><div style="font-size:11px;color:var(--muted)">Sat · 8 PM</div></div></div>
      </div>
      <div class="glass tight" onclick="go('ai')" style="background:rgba(124,92,252,.14);cursor:pointer">
        <div class="row" style="gap:7px">${ic('spark','var(--violet)',15,2.2)}<p class="eyebrow" style="color:var(--violet)">Suggested</p></div>
        <div class="stack" style="gap:7px;margin-top:10px">
          ${['Cap food spending at ₹150/day','Try 2 min of breathing','Write today\'s best moment'].map(t=>`<div style="font-size:11.5px;font-weight:600;background:var(--glass2);padding:8px 10px;border-radius:11px;line-height:1.35">${t}</div>`).join('')}
        </div>
      </div>
    </div>

    <div class="glass" style="margin-top:12px;background:linear-gradient(135deg,rgba(255,184,77,.14),rgba(255,110,127,.1));border:0">
      <p class="eyebrow">Quote of the day</p>
      <div style="font-family:var(--disp);font-size:16px;letter-spacing:-.01em;margin-top:7px;font-weight:600">"Small consistent steps beat big perfect plans."</div>
    </div>
  </div>
  ${tabbar('dashboard')}
</div>`);

/* =================== 8b. Quick actions =================== */
reg('quickactions','Home & AI','Quick Actions',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Today',{back:true})}
    <div class="list">
      ${[['CS Lab','2:00 PM · Block C','cal','#7C5CFC'],['Movie night RSVP','Due tonight','users','#FF6E7F'],['Pay hostel dues','₹1,200 due Friday','wallet','#FFB84D']].map(([t,s,i,c])=>
      `<div class="item"><div class="sqico" style="background:${c}26">${ic(i,c,17,2.1)}</div><div class="col"><div class="t">${t}</div><div class="s">${s}</div></div>${ic('chev','var(--muted)',16)}</div>`).join('')}
    </div>
  </div>
</div>`);

/* =================== 9. AI assistant =================== */
reg('ai','Home & AI','AI Assistant',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body" style="padding-bottom:12px">
    <div class="navbar">
      <button class="iconbtn" onclick="back()">${ic('back','currentColor',19)}</button>
      <div style="flex:1"><div class="row" style="gap:8px"><div style="width:26px;height:26px;border-radius:9px;background:linear-gradient(135deg,var(--violet),var(--cyan));display:grid;place-items:center">${ic('spark','#fff',14,2.3)}</div><h2 style="font-size:18px">NEXORA AI</h2></div></div>
      <button class="iconbtn" onclick="toast('Listening…','mic','#7C5CFC')">${ic('mic','currentColor',18)}</button>
    </div>
    <div class="stack" style="gap:14px">
      <div style="align-self:flex-end;max-width:76%;background:linear-gradient(135deg,var(--violet),#9B7BFF);color:#fff;padding:12px 15px;border-radius:20px 20px 6px 20px;font-size:14px;line-height:1.5;font-weight:500">I'm having a stressful day.</div>
      <div style="max-width:88%" class="glass" style="border-radius:20px 20px 20px 6px">
        <div class="glass" style="border-radius:20px 20px 20px 6px;padding:14px 15px;font-size:14px;line-height:1.6">
          That's a lot to carry. Want two minutes to reset, or to talk through what's making today hard?
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:9px">
          <button class="pill cyan" onclick="go('moodcheck')">Start breathing</button>
          <button class="pill on" onclick="go('stress')">Open Stress Buster</button>
        </div>
      </div>
      <div style="align-self:flex-end;max-width:76%;background:linear-gradient(135deg,var(--violet),#9B7BFF);color:#fff;padding:12px 15px;border-radius:20px 20px 6px 20px;font-size:14px;line-height:1.5;font-weight:500">Help me plan my weekend budget.</div>
      <div class="glass" style="border-radius:20px 20px 20px 6px;max-width:92%">
        <div class="between"><p class="eyebrow">Weekend budget</p><span class="pill amber">Demo data</span></div>
        <div class="big" style="margin:9px 0 3px">₹1,800</div>
        <p class="p" style="font-size:12.5px">Based on your average weekend spend, plus the ₹500 you've pledged to the trip fund.</p>
        <button class="btn sec sm" style="width:100%;margin-top:12px" onclick="go('moneyplan')">See the trip fund</button>
      </div>
      <div style="align-self:flex-end;max-width:76%;background:linear-gradient(135deg,var(--violet),#9B7BFF);color:#fff;padding:12px 15px;border-radius:20px 20px 6px 20px;font-size:14px;line-height:1.5;font-weight:500">Where's Priya?</div>
      <div class="glass" style="border-radius:20px 20px 20px 6px;max-width:80%" onclick="go('track')">
        <div class="row" style="gap:10px">${ic('pin','var(--cyan)',18,2.2)}<div><div style="font-size:13px;font-weight:700">400 m away, at the library</div><p class="p" style="font-size:11.5px;margin-top:2px">She's sharing with you until 6:20 PM</p></div></div>
      </div>
      <div class="glass" style="border-radius:20px 20px 20px 6px;max-width:60%;color:var(--muted)" class="dots"><span></span><span></span><span></span></div>
    </div>
  </div>
  <div style="padding:8px 16px 30px;background:var(--glass);backdrop-filter:var(--blur);border-top:1px solid var(--hair)">
    <div class="chips" style="padding:0 0 10px;margin:0">${['Summarize my week','Suggest something fun','Give me a motivation boost','Explain a topic'].map(t=>`<span class="pill">${t}</span>`).join('')}</div>
    <div class="field" style="padding:7px 8px 7px 14px">
      <input placeholder="Ask NEXORA anything…"><button class="iconbtn" style="background:linear-gradient(135deg,var(--violet),var(--cyan));border:0" onclick="toast('Thinking…','spark','#7C5CFC')">${ic('send','#fff',17)}</button>
    </div>
    <p class="p" style="font-size:10.5px;text-align:center;margin-top:8px">AI-generated. NEXORA doesn't invent news and never impersonates people.</p>
  </div>
</div>`);

/* =================== 10. Notifications =================== */
reg('notifs','Home & AI','Notifications',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Notifications',{back:true,right:`<button class="pill" onclick="toast('All caught up.')">Mark read</button>`})}
    <div class="chips" style="margin-bottom:14px">${['All','Security','Money','Location','Chat'].map((t,i)=>`<span class="pill ${i?'':'on'}">${t}</span>`).join('')}</div>
    <p class="eyebrow" style="margin:2px 2px 8px">Today</p>
    <div class="list">
      ${[['New sign-in from iPhone 15 Pro','Chennai · 9:41 AM. Was this you?','shield','#FFB84D','newlogin',1],
         ['Priya requested to track with you','Meet near the library','pin','#35E1C8','track',1],
         ['Balance getting low','₹3,240 left with 11 days to go','wallet','#FF6E7F','money',1],
         ['Trip fund update','Jordan added ₹500 · 68% funded','gift','#7C5CFC','moneyplan',0]].map(([t,s,i,c,to,unread])=>
      `<div class="item" onclick="go('${to}')" style="${unread?'background:rgba(124,92,252,.06)':''}">
        <div class="sqico" style="background:${c}26">${ic(i,c,17,2.1)}</div><div class="col"><div class="t" style="white-space:normal">${t}</div><div class="s" style="white-space:normal">${s}</div></div>
        ${unread?'<span style="width:8px;height:8px;border-radius:8px;background:var(--violet);flex:0 0 8px"></span>':ic('chev','var(--muted)',16)}
      </div>`).join('')}
    </div>
    <p class="eyebrow" style="margin:18px 2px 8px">Earlier</p>
    <div class="list">
      ${[['Track completed with Jordan','You met at the quad · 4:12 PM','check','#35E1C8'],
         ['Diary reminder','You haven\'t written since Tuesday','book','#7C5CFC'],
         ['NEXORA AI suggestion','A weekday food cap could help','spark','#9B7BFF']].map(([t,s,i,c])=>
      `<div class="item"><div class="sqico" style="background:${c}26">${ic(i,c,17,2.1)}</div><div class="col"><div class="t" style="white-space:normal">${t}</div><div class="s" style="white-space:normal">${s}</div></div>${ic('chev','var(--muted)',16)}</div>`).join('')}
    </div>
  </div>
</div>`);

/* =================== 11. Stress Buster Home =================== */
reg('stress','Stress Buster','Stress Buster Home',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body tabbed">
    ${nav('Stress Buster',{right:`<button class="iconbtn" onclick="go('talk')" style="color:var(--coral)">${ic('help','var(--coral)',18,2.2)}</button>`})}
    <div class="glass" style="background:linear-gradient(135deg,rgba(255,110,127,.85),rgba(255,184,77,.55));border:0;padding:20px;color:#2A0F16">
      <p style="font-size:12px;font-weight:700;opacity:.7;margin:0">Today's affirmation</p>
      <div style="font-family:var(--disp);font-size:23px;line-height:1.22;letter-spacing:-.01em;margin-top:10px;font-weight:700">You're allowed to move at your own pace.</div>
      <div class="row" style="margin-top:16px;gap:8px">
        <button class="pill" style="background:rgba(255,255,255,.4);color:#2A0F16" onclick="toast('Saved to your diary.','book','#7C5CFC')">${ic('heart','#2A0F16',14,2.4)} Keep</button>
        <button class="pill" style="background:rgba(255,255,255,.4);color:#2A0F16" onclick="toast('Shared.','send','#FF6E7F')">${ic('share','#2A0F16',14,2.4)} Share</button>
      </div>
    </div>

    <div class="glass" style="margin-top:14px" onclick="go('moodcheck')">
      <div class="h3">How are you feeling today?</div>
      <div class="row" style="gap:8px;margin-top:14px;justify-content:space-between">
        ${[['😄','Great'],['🙂','Good'],['😐','Okay'],['😔','Low'],['😣','Rough']].map(([e,l])=>
        `<div style="text-align:center;flex:1"><div style="height:50px;border-radius:16px;background:var(--glass2);display:grid;place-items:center;font-size:22px">${e}</div><div style="font-size:10.5px;font-weight:700;color:var(--muted);margin-top:6px">${l}</div></div>`).join('')}
      </div>
    </div>

    <div class="grid2" style="margin-top:12px">
      <button class="glass tight" style="text-align:left" onclick="go('talk')">
        <div class="sqico" style="background:rgba(255,110,127,.2)">${ic('heart','var(--coral)',17,2.2)}</div>
        <div style="font-size:14px;font-weight:800;margin-top:10px;letter-spacing:-.005em">Need someone to talk to?</div>
        <p class="p" style="font-size:11.5px;margin-top:3px">Support, right now</p>
      </button>
      <button class="glass tight" style="text-align:left" onclick="go('moodcheck')">
        <div class="sqico" style="background:rgba(124,92,252,.2)">${ic('grid','var(--violet)',17,2.2)}</div>
        <div style="font-size:14px;font-weight:800;margin-top:10px;letter-spacing:-.005em">Study-break check-in</div>
        <p class="p" style="font-size:11.5px;margin-top:3px">A short reset between tasks</p>
      </button>
    </div>

    <h3 class="section-title">Short relaxation activities</h3>
    <div class="stack">
      ${[['Box breathing','4 in · 4 hold · 4 out · 4 hold','wind','#35E1C8','2 min'],
         ['5-4-3-2-1 grounding','Name what you can see and hear','mood','#7C5CFC','3 min'],
         ['Shoulder release','For long study sessions','star','#FFB84D','90 sec'],
         ['Wind-down for sleep','Dim, slow, phone down','clock','#9B7BFF','6 min']].map(([t,s,i,c,d])=>
      `<div class="glass tight row" onclick="go('moodcheck')" style="cursor:pointer">
        <div class="sqico" style="background:${c}26;width:42px;height:42px;flex:0 0 42px;border-radius:14px">${ic(i,c,19,2.1)}</div>
        <div style="flex:1"><div style="font-size:14px;font-weight:700;letter-spacing:-.005em">${t}</div><p class="p" style="font-size:11.5px;margin-top:2px">${s}</p></div>
        <span class="pill">${d}</span>
      </div>`).join('')}
    </div>

    <h3 class="section-title">Mood history</h3>
    <div class="glass">
      <div class="row" style="gap:4px;align-items:flex-end;height:70px">
        ${[6,5,7,4,6,8,7].map((h,i)=>`<div style="flex:1;text-align:center"><div style="height:${h*7}px;border-radius:6px 6px 2px 2px;background:linear-gradient(180deg,var(--violet),var(--cyan));opacity:${.4+h/12}"></div><div style="font-size:9.5px;color:var(--muted);margin-top:6px;font-weight:700">${'MTWTFSS'[i]}</div></div>`).join('')}
      </div>
    </div>

    <div class="glass" style="margin-top:14px;background:var(--glass2)">
      <p class="p" style="font-size:12px">NEXORA's AI is here to support, not to diagnose. For anything that feels too big, reach a trusted adult or use <b style="color:var(--coral)" onclick="go('talk')">Need someone to talk to?</b></p>
    </div>
  </div>
  ${tabbar('stress')}
</div>`);

/* =================== 12. Mood check + AI support =================== */
reg('moodcheck','Stress Buster','Mood Check + AI Support',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('How are you feeling?',{back:true,sub:'Only you can see this.'})}
    <div style="text-align:center;padding:6px 0 4px">
      <div style="font-size:70px;line-height:1;animation:pin .4s cubic-bezier(.32,.72,0,1)" id="moodFace">🙂</div>
      <div class="big" style="font-size:24px;margin-top:12px" id="moodName">Good</div>
      <p class="p" style="margin-top:6px" id="moodHint">A steady sort of day.</p>
    </div>
    <div class="glass" style="margin-top:16px">
      <div class="between" style="margin-bottom:12px"><p class="eyebrow">Stress-level check-in</p><span class="pill cyan" id="moodScore">4 / 10</span></div>
      <input type="range" min="1" max="10" value="4" oninput="setMood(this.value)" style="width:100%;accent-color:#7C5CFC;height:26px">
      <div class="between"><span style="font-size:11px;color:var(--muted);font-weight:700">Calm</span><span style="font-size:11px;color:var(--muted);font-weight:700">Overwhelmed</span></div>
    </div>
    <div class="glass" style="margin-top:14px">
      <p class="eyebrow">Tell me what's on your mind…</p>
      <textarea rows="4" style="width:100%;border:0;background:none;outline:none;resize:none;font:500 14px/1.6 var(--sans);color:var(--text);margin-top:8px" placeholder="Type as much or as little as you like.">Two assignments due tomorrow and I keep switching between them without finishing either.</textarea>
      <div class="between" style="border-top:1px solid var(--hair);padding-top:11px">
        <div class="row" style="gap:6px;color:var(--muted)">${ic('lock','var(--muted)',14,2.2)}<span style="font-size:11px;font-weight:700">Private to you</span></div>
      </div>
    </div>
    <div class="stack" style="margin-top:14px">
      <button class="btn cyan" onclick="go('talk')">Talk it through with NEXORA</button>
      <button class="btn line" onclick="toast('Mood logged.','check');setTimeout(back,650)">Just log it</button>
    </div>
  </div>
</div>`);
function setMood(v){
  v=+v; const set=[[2,'😄','Great','Nice — worth remembering what helped.'],[4,'🙂','Good','A steady sort of day.'],[6,'😐','Okay','Not bad, not great. That\'s fair.'],[8,'😔','Low','Low energy is information, not failure.'],[10,'😣','Rough','Hard days count too. Be gentle with yourself.']];
  const m=set.find(s=>v<=s[0])||set[4];
  document.getElementById('moodFace').textContent=m[1]; document.getElementById('moodName').textContent=m[2];
  document.getElementById('moodHint').textContent=m[3]; document.getElementById('moodScore').textContent=v+' / 10';
}

/* =================== 13. Talk / AI support conversation =================== */
reg('talk','Stress Buster','AI Feelings Conversation',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body" style="padding-bottom:10px">
    <div class="navbar">
      <button class="iconbtn" onclick="back()">${ic('back','currentColor',19)}</button>
      <div style="flex:1"><h2 style="font-size:19px">Let's talk it through</h2><p class="p" style="font-size:11.5px">Private · supportive, not a therapist</p></div>
    </div>
    <div class="stack" style="gap:14px">
      <div style="align-self:flex-end;max-width:78%;background:linear-gradient(135deg,var(--cyan),#57F0D8);color:#04241D;padding:12px 15px;border-radius:20px 20px 6px 20px;font-size:14px;line-height:1.5;font-weight:600">Two assignments due tomorrow and I keep switching between them without finishing either.</div>
      <div class="glass" style="border-radius:20px 20px 20px 6px;max-width:88%;font-size:14px;line-height:1.6">
        Switching like that usually means both feel equally urgent, so it's hard to choose. Let's take the choice away for 25 minutes.
      </div>
      <div class="glass" style="border-radius:20px 20px 20px 6px;max-width:94%">
        <p class="eyebrow">A plan for tonight</p>
        <div class="stack" style="gap:9px;margin-top:11px">
          ${[['7:30','Report — intro and methods only'],['7:55','Stand up, water, step away for 5'],['8:00','Design task — just the wireframes'],['8:25','Stop. What\'s done is enough for today.']].map(([t,d])=>
          `<div class="row" style="gap:11px"><span style="font-family:var(--disp);font-size:12.5px;font-weight:700;color:var(--cyan);width:38px">${t}</span><span style="font-size:13px;line-height:1.4;flex:1">${d}</span></div>`).join('')}
        </div>
        <div class="row" style="gap:8px;margin-top:14px">
          <button class="btn sm cyan" style="flex:1" onclick="toast('Plan added to today.','check')">Use this plan</button>
          <button class="btn sm sec" onclick="toast('Rewriting…','spark','#7C5CFC')">Adjust</button>
        </div>
      </div>
      <div class="glass" style="border-radius:20px;text-align:center;padding:20px;max-width:82%" onclick="toast('Nice work. Logged as calmer.','check')">
        <div style="width:92px;height:92px;margin:0 auto;border-radius:50%;background:rgba(53,225,200,.16);display:grid;place-items:center;animation:breathe 8s ease-in-out infinite">
          <div style="width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,var(--cyan),#57F0D8);display:grid;place-items:center;color:#04241D;font-size:11.5px;font-weight:800">Breathe</div>
        </div>
        <p class="p" style="font-size:12.5px;margin-top:13px">Tap to start box breathing</p>
        <style>@keyframes breathe{0%,100%{transform:scale(.86)}50%{transform:scale(1.1)}}</style>
      </div>
    </div>
  </div>
  <div style="padding:8px 16px 30px;background:var(--glass);backdrop-filter:var(--blur);border-top:1px solid var(--hair)">
    <div class="chips" style="padding:0 0 10px;margin:0">${['That helps','I\'d rather just vent','Still anxious','Need someone to talk to?'].map((t,i)=>`<span class="pill ${i===3?'coral':''}" onclick="${i===3?"go('helpline')":''}">${t}</span>`).join('')}</div>
    <div class="field" style="padding:7px 8px 7px 14px"><input placeholder="Say anything…"><button class="iconbtn" style="background:linear-gradient(135deg,var(--cyan),#57F0D8);border:0">${ic('send','#04241D',17)}</button></div>
  </div>
</div>`);

/* =================== 13b. Helpline / trusted support =================== */
reg('helpline','Stress Buster','Trusted Support Pathway',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Need someone now?',{back:true,sub:'NEXORA isn\'t a counsellor. A person helps more than an app can.'})}
    <div class="list">
      ${[['Campus counsellor','Health centre · 9 AM–6 PM','user','#7C5CFC'],['National helpline','Free, confidential, 24×7','phone','#FF6E7F'],['A trusted person','A parent, friend or mentor','heart','#35E1C8']].map(([t,s,i,c])=>
      `<div class="item"><div class="sqico" style="background:${c}26">${ic(i,c,17,2.1)}</div><div class="col"><div class="t">${t}</div><div class="s">${s}</div></div>${ic('chev','var(--muted)',16)}</div>`).join('')}
    </div>
    <button class="btn" style="margin-top:16px" onclick="back()">Close</button>
  </div>
</div>`);

/* =================== 15. Money Guard dashboard =================== */
const TXN=[['Campus cafe — dinner','Food','−₹380','Today, 8:52 PM','wallet','#FFB84D'],
  ['Mom','Received','+₹2,500','Today, 8:05 AM','gift','#35E1C8'],
  ['Metro card top-up','Transport','−₹200','Yesterday','nav','#7C5CFC'],
  ['Printing — notes','Education','−₹60','Yesterday','book','#9B7BFF'],
  ['Trip fund top-up','Friends','−₹300','Wed','users','#FF6E7F'],
  ['Streaming sub','Entertainment','−₹149','Tue','star','#FFB84D']];
reg('money','Money Guard','Money Guard Dashboard',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body tabbed">
    ${nav('Money Guard',{right:`<span class="pill amber">Demo data</span>`})}
    <div class="glass" style="background:linear-gradient(135deg,#FFB84D,#FF9A4D);border:0;color:#2B1600;padding:20px">
      <div class="between"><p style="font-size:12px;font-weight:700;opacity:.65;margin:0">Available funds</p>${ic('wallet','#2B1600',18,2.2)}</div>
      <div style="font-family:var(--disp);font-size:40px;font-weight:700;letter-spacing:-.02em;margin:8px 0 2px">₹3,240</div>
      <p style="font-size:12px;font-weight:600;opacity:.7;margin:0">41% of this month's ₹8,000 left · 11 days to go</p>
      <div style="height:8px;border-radius:8px;background:rgba(43,22,0,.16);margin-top:15px;overflow:hidden"><div style="width:41%;height:100%;background:#2B1600;border-radius:8px"></div></div>
      <div class="row" style="gap:18px;margin-top:16px">
        <div><p style="font-size:11px;font-weight:700;opacity:.6;margin:0">Received</p><div style="font-family:var(--disp);font-size:16px;font-weight:700;margin-top:2px">₹8,000</div></div>
        <div><p style="font-size:11px;font-weight:700;opacity:.6;margin:0">Spent</p><div style="font-family:var(--disp);font-size:16px;font-weight:700;margin-top:2px">₹4,760</div></div>
        <button class="btn sm" style="margin-left:auto;background:#2B1600;color:#fff;box-shadow:none" onclick="go('addtxn')">${ic('plus','#fff',16,2.6)} Add</button>
      </div>
    </div>

    <div class="glass tight row" style="gap:11px;margin-top:14px;background:rgba(255,110,127,.14);border:0">
      <div class="sqico" style="background:#FF4D5E">${ic('alert','#fff',17,2.2)}</div>
      <div style="flex:1"><div style="font-size:13px;font-weight:800">Your available balance is getting low</div><p class="p" style="font-size:11.5px">Review your spending plan?</p></div>
    </div>

    <div class="between" style="margin:22px 2px 10px"><h3 class="section-title" style="margin:0">This week</h3><span style="font-size:12px;font-weight:700;color:var(--amber)" onclick="go('analytics')">Analytics</span></div>
    <div class="glass">
      <div class="row" style="gap:5px;align-items:flex-end;height:100px">
        ${[[380,'M'],[520,'T'],[300,'W'],[760,'T'],[420,'F'],[610,'S'],[190,'S']].map(([v,d])=>
        `<div style="flex:1;text-align:center"><div style="height:${v/9}px;border-radius:7px 7px 3px 3px;background:${v>600?'var(--amber)':'rgba(255,184,77,.32)'};transition:height .5s"></div><div style="font-size:10px;color:var(--muted);margin-top:7px;font-weight:700">${d}</div></div>`).join('')}
      </div>
    </div>

    <div class="between" style="margin:22px 2px 10px"><h3 class="section-title" style="margin:0">Group plans</h3><span style="font-size:12px;font-weight:700;color:var(--amber)" onclick="go('moneyplan')">All plans</span></div>
    <div class="glass" onclick="go('sharedgoal')" style="cursor:pointer">
      <div class="between">
        <div class="row" style="gap:11px"><div class="sqico" style="background:rgba(53,225,200,.18);width:40px;height:40px;flex:0 0 40px;border-radius:14px">${ic('gift','var(--cyan)',19,2.1)}</div>
        <div><div style="font-size:14.5px;font-weight:800">Trip fund — Pondicherry</div><p class="p" style="font-size:11.5px">4 people · ₹500 each</p></div></div>
        <span class="pill cyan">68%</span>
      </div>
      <div class="bar" style="margin-top:13px"><span style="width:68%"></span></div>
      <div class="between" style="margin-top:8px"><span style="font-size:11.5px;color:var(--muted);font-weight:700">₹1,360 saved</span><span style="font-size:11.5px;color:var(--muted);font-weight:700">Goal ₹2,000</span></div>
    </div>

    <div class="between" style="margin:22px 2px 10px"><h3 class="section-title" style="margin:0">Recent</h3><span style="font-size:12px;font-weight:700;color:var(--amber)" onclick="go('txns')">See all</span></div>
    <div class="list">
      ${TXN.slice(0,4).map(([t,c,a,d,i,col])=>
      `<div class="item"><div class="sqico" style="background:${col}26">${ic(i,col,17,2.1)}</div><div class="col"><div class="t">${t}</div><div class="s">${c} · ${d}</div></div><div style="font-family:var(--disp);font-size:14.5px;font-weight:700;color:${a[0]==='+'?'#35E1C8':'var(--text)'}">${a}</div></div>`).join('')}
    </div>
  </div>
  ${tabbar('money')}
</div>`);

/* =================== 15b. Add transaction =================== */
reg('addtxn','Money Guard','Add Transaction',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Add a transaction',{back:true})}
    <div class="stack">
      <div class="field"><div class="col"><label>Amount</label><input value="₹ 250"></div></div>
      <div class="field"><div class="col"><label>What for</label><input placeholder="e.g. Bus pass"></div></div>
      <div><p class="eyebrow" style="margin-bottom:8px">Category</p><div style="display:flex;flex-wrap:wrap;gap:7px">${['Food','Transport','Shopping','Entertainment','Education','Friends','Other'].map((c,i)=>`<span class="pill ${i?'':'on'}">${c}</span>`).join('')}</div></div>
      <button class="btn" onclick="txnAdded();back()">Save transaction</button>
    </div>
    <p class="p" style="text-align:center;font-size:11.5px;margin-top:14px">Prototype only — no real bank account is connected.</p>
  </div>
</div>`);

/* =================== 16. Spending analytics =================== */
reg('analytics','Money Guard','Spending Analytics',()=>{
  const cats=[['Food',1180,'#FFB84D'],['Transport',640,'#7C5CFC'],['Entertainment',540,'#9B7BFF'],['Education',420,'#35E1C8'],['Shopping',380,'#FF6E7F'],['Friends',300,'#FFB84D'],['Other',200,'#9691C4']];
  const total=cats.reduce((a,c)=>a+c[1],0); let off=0;
  const donut=cats.map(([n,v,c])=>{const len=v/total*283, d=`<circle cx="60" cy="60" r="45" fill="none" stroke="${c}" stroke-width="17" stroke-dasharray="${len-2.5} ${283-len+2.5}" stroke-dashoffset="${-off}" transform="rotate(-90 60 60)" stroke-linecap="round"/>`; off+=len; return d;}).join('');
  return `
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body tabbed">
    ${nav('Analytics',{back:true,right:`<span class="pill amber">Demo data</span>`})}
    <div class="chips" style="margin-bottom:14px">${['Week','Month','Semester'].map((t,i)=>`<span class="pill ${i===1?'on':''}" onclick="document.querySelectorAll('.chips .pill').forEach(p=>p.classList.remove('on'));this.classList.add('on')">${t}</span>`).join('')}</div>
    <div class="glass" style="text-align:center">
      <div style="position:relative;width:120px;height:120px;margin:4px auto 0">
        <svg width="120" height="120" viewBox="0 0 120 120">${donut}</svg>
        <div style="position:absolute;inset:0;display:grid;place-content:center"><div class="big" style="font-size:22px">₹${total.toLocaleString('en-IN')}</div><p class="p" style="font-size:10.5px;margin-top:2px">this month</p></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-top:18px;text-align:left">
        ${cats.map(([n,v,c])=>`<div class="row" style="gap:8px"><span style="width:9px;height:9px;border-radius:3px;background:${c};flex:0 0 9px"></span><span style="font-size:11.5px;font-weight:700;flex:1">${n}</span><span style="font-size:11.5px;color:var(--muted);font-weight:700">₹${v}</span></div>`).join('')}
      </div>
    </div>
    <h3 class="section-title">Spending trend</h3>
    <div class="glass">
      <svg viewBox="0 0 320 130" style="width:100%;height:130px">
        ${[0,1,2,3].map(i=>`<line x1="0" y1="${18+i*30}" x2="320" y2="${18+i*30}" stroke="var(--hair)" stroke-width="1"/>`).join('')}
        <path d="M8 96 L60 74 L112 84 L164 46 L216 60 L268 32 L312 44" fill="none" stroke="#FFB84D" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
        ${[[8,96],[60,74],[112,84],[164,46],[216,60],[268,32],[312,44]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3.6" fill="var(--bg)" stroke="#FFB84D" stroke-width="2.6"/>`).join('')}
        ${['Jan','Feb','Mar','Apr','May','Jun','Jul'].map((m,i)=>`<text x="${8+i*50.6}" y="130" font-size="9" font-weight="700" fill="var(--muted)" text-anchor="middle" font-family="Inter">${m}</text>`).join('')}
      </svg>
      <p class="p" style="font-size:12px;margin-top:6px">This month is your highest so far — two weekend trips account for most of it.</p>
    </div>
    <div class="glass" style="margin-top:14px;background:rgba(124,92,252,.12);border:0">
      <div class="row" style="gap:9px;margin-bottom:8px">${ic('spark','var(--violet)',16,2.2)}<p class="eyebrow" style="color:var(--violet)">Savings suggestion</p></div>
      <p class="p" style="font-size:13px;color:var(--text)">Late-night food orders are ₹1,340 this month. A ₹150 weekday evening cap frees up roughly one weekend out.</p>
      <button class="btn sm" style="background:var(--violet);margin-top:12px" onclick="toast('Weekday cap set at ₹150.','check')">Set that cap</button>
    </div>
  </div>
  ${tabbar('money')}
</div>`;});

/* =================== 17. Money plan (group savings) =================== */
reg('moneyplan','Money Guard','Money Plan',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body tabbed">
    ${nav('Group money plans',{back:true,sub:'Trip, birthday, event or dinner — save together.'})}
    <div class="glass" onclick="go('sharedgoal')" style="cursor:pointer;border:1.5px solid var(--cyan)">
      <div class="between"><div class="row" style="gap:10px"><div class="sqico" style="background:rgba(53,225,200,.2)">${ic('gift','var(--cyan)',17,2.1)}</div><div style="font-size:14.5px;font-weight:800">Trip fund — Pondicherry</div></div><span class="pill cyan">Active</span></div>
      <div class="row" style="gap:18px;margin:15px 0 12px">
        ${[['Friends','4'],['Each','₹500'],['Goal','₹2,000'],['Saved','₹1,360']].map(([k,v])=>`<div><p class="eyebrow" style="font-size:10.5px">${k}</p><div style="font-family:var(--disp);font-size:15.5px;font-weight:700;margin-top:2px">${v}</div></div>`).join('')}
      </div>
      <div class="bar"><span style="width:68%"></span></div>
      <div style="display:flex;margin-top:12px">${[['A','#7C5CFC'],['P','#35E1C8'],['J','#FFB84D'],['R','#FF6E7F']].map(([i,c],n)=>`<div style="margin-left:${n?'-10px':'0'};border:2.5px solid var(--bg);border-radius:50%">${av(i,c,30,11)}</div>`).join('')}<span style="font-size:11.5px;color:var(--muted);font-weight:700;margin-left:12px;align-self:center">Priya, Jordan, Rhea</span></div>
    </div>

    <h3 class="section-title">Start a new plan</h3>
    <div class="glass stack">
      <div class="field" style="background:var(--glass2)"><div class="col"><label>Plan name</label><input value="Diya's birthday dinner"></div></div>
      <div class="grid2">
        <div class="field" style="background:var(--glass2)"><div class="col"><label>Target amount</label><input value="₹6,000"></div></div>
        <div class="field" style="background:var(--glass2)"><div class="col"><label>People</label><input value="6"></div></div>
      </div>
      <div class="glass tight between" style="background:rgba(53,225,200,.14);border:0">
        <div><p class="eyebrow">Each person contributes</p><div class="big" style="font-size:20px;margin-top:3px">₹1,000</div></div>${ic('users','var(--cyan)',22,2)}
      </div>
      <div class="row" style="gap:9px;align-items:flex-start">
        <div class="switch on" onclick="tog(this)" style="margin-top:2px"></div>
        <p class="p" style="font-size:12px">Only verified NEXORA friends can join, and every contribution is visible to everyone in the plan.</p>
      </div>
      <button class="btn cyan" onclick="toast('Diya birthday dinner created. Invites sent.','check')">Create plan</button>
    </div>
  </div>
  ${tabbar('money')}
</div>`);

/* =================== 18. Shared money goal =================== */
reg('sharedgoal','Money Guard','Shared Money Goal',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body tabbed">
    ${nav('Trip fund — Pondicherry',{back:true,right:`<button class="iconbtn" onclick="go('goalperms')">${ic('cog','currentColor',18)}</button>`})}
    <div class="glass" style="text-align:center;background:linear-gradient(135deg,#35E1C8,#57F0D8);border:0;color:#04241D">
      <p style="font-size:12px;font-weight:700;opacity:.65;margin:0">Saved so far</p>
      <div style="font-family:var(--disp);font-size:42px;font-weight:700;letter-spacing:-.02em;margin:6px 0 2px">₹1,360</div>
      <p style="font-size:12.5px;font-weight:700;opacity:.7;margin:0">of ₹2,000 · ₹640 to go</p>
      <div style="height:10px;border-radius:10px;background:rgba(4,36,29,.16);margin-top:16px;overflow:hidden"><div style="width:68%;height:100%;background:#04241D;border-radius:10px"></div></div>
      <div class="row" style="gap:8px;margin-top:16px">
        <button class="btn sm" style="flex:1;background:#04241D;color:#fff;box-shadow:none" onclick="go('addcontribution')">Add contribution</button>
        <button class="btn sm" style="flex:1;background:rgba(4,36,29,.14);color:#04241D;box-shadow:none" onclick="toast('Invite link copied.','share','#35E1C8')">Invite</button>
      </div>
    </div>
    <h3 class="section-title">Contributors</h3>
    <div class="list">
      ${[['Alex (you)','₹500 of ₹500','A','#7C5CFC',100],['Priya','₹500 of ₹500','P','#35E1C8',100],['Jordan','₹360 of ₹500','J','#FFB84D',72],['Rhea','Not yet added','R','#FF6E7F',0]].map(([n,s,i,c,p])=>
      `<div class="item"><div>${av(i,c,36,13)}</div><div class="col"><div class="t">${n}</div><div class="s">${s}</div></div>
      ${p===100?`<span class="pill cyan">${ic('check','#26C9AE',12,3)} Paid</span>`:p?`<div style="width:54px"><div class="bar" style="height:6px"><span style="width:${p}%"></span></div></div>`:`<button class="pill" onclick="event.stopPropagation();toast('Nudge sent to Rhea.','bell','#FFB84D')">Nudge</button>`}</div>`).join('')}
    </div>
    <h3 class="section-title">Contribution history</h3>
    <div class="list">
      ${[['Jordan added ₹360','Today, 6:20 PM','J','#FFB84D'],['Priya added ₹500','Wed, 11:04 AM','P','#35E1C8'],['You added ₹500','Wed, 9:30 AM','A','#7C5CFC']].map(([t,d,i,c])=>
      `<div class="item"><div>${av(i,c,32,12)}</div><div class="col"><div class="t" style="font-size:13.5px">${t}</div><div class="s">${d}</div></div></div>`).join('')}
    </div>
    <p class="p" style="text-align:center;font-size:11.5px;margin-top:14px">Prototype wallet. NEXORA shows amounts and names only — never card numbers or OTPs.</p>
  </div>
  ${tabbar('money')}
</div>`);

reg('addcontribution','Money Guard','Add Contribution',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Add your contribution',{back:true})}
    <div class="big" style="text-align:center;margin:24px 0 6px;font-size:40px">₹500</div>
    <p class="p" style="text-align:center;font-size:12px">Simulated payment — no real money moves</p>
    <div class="row" style="gap:8px;justify-content:center;margin:18px 0">${[100,250,500,1000].map(v=>`<span class="pill ${v===500?'on':''}">₹${v}</span>`).join('')}</div>
    <button class="btn cyan" onclick="goalAdded();back()">Add ₹500</button>
  </div>
</div>`);

reg('goalperms','Money Guard','Goal Permissions',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Who can do what',{back:true})}
    <div class="list">
      ${[['Alex (you)','Owner · can edit & remove'],['Priya','Can add money'],['Jordan','Can add money'],['Rhea','View only']].map(([n,r])=>
      `<div class="item"><div class="col"><div class="t">${n}</div><div class="s">${r}</div></div>${ic('chev','var(--muted)',16)}</div>`).join('')}
    </div>
  </div>
</div>`);

/* =================== 19. Transaction history =================== */
reg('txns','Money Guard','Transaction History',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body tabbed">
    ${nav('Transactions',{back:true,right:`<button class="iconbtn">${ic('search','currentColor',18)}</button>`})}
    <div class="chips" style="margin-bottom:14px">${['All','Food','Transport','Friends','Received'].map((t,i)=>`<span class="pill ${i?'':'on'}">${t}</span>`).join('')}</div>
    <div class="list">${TXN.map(([t,c,a,d,i,col])=>
      `<div class="item"><div class="sqico" style="background:${col}26">${ic(i,col,17,2.1)}</div><div class="col"><div class="t">${t}</div><div class="s">${c} · ${d}</div></div><div style="font-family:var(--disp);font-size:14.5px;font-weight:700;color:${a[0]==='+'?'#35E1C8':'var(--text)'}">${a}</div></div>`).join('')}</div>
    <p class="p" style="text-align:center;font-size:11.5px;margin-top:16px">Demo data for the prototype. No bank account is connected.</p>
  </div>
  ${tabbar('money')}
</div>`);

/* =================== map helper =================== */
function mapSvg({route=false,you=[196,470],friend=[250,180],others=[],h='100%'}={}){
  const dark = document.documentElement.dataset.theme!=='light';
  const land = dark?'#12142A':'#EEEBFA', road=dark?'#1D2040':'#FFFFFF', block=dark?'#191B38':'#E1DCF6', park=dark?'#132A2E':'#D3F3EA', water=dark?'#111A38':'#D4E4FB';
  const blocks=[[16,60,80,70],[120,40,90,60],[230,80,110,90],[20,160,70,90],[110,130,70,80],[30,300,90,100],[150,280,110,120],[280,220,80,110],[40,440,100,90],[180,430,120,100],[300,380,70,120],[110,560,140,90],[20,600,70,80],[280,540,90,130]];
  return `<svg viewBox="0 0 393 700" style="width:100%;height:${h};display:block" preserveAspectRatio="xMidYMid slice">
    <rect width="393" height="700" fill="${land}"/>
    <path d="M300 0 L393 0 L393 140 L330 120 Z" fill="${water}"/>
    <rect x="140" y="170" width="120" height="90" rx="10" fill="${park}"/>
    ${blocks.map(([x,y,w,hh])=>`<rect x="${x}" y="${y}" width="${w}" height="${hh}" rx="7" fill="${block}"/>`).join('')}
    ${[30,150,270,410,530].map(p=>`<line x1="0" y1="${p}" x2="393" y2="${p}" stroke="${road}" stroke-width="13" stroke-linecap="round"/>`).join('')}
    ${[105,225,270,345].map(p=>`<line x1="${p}" y1="0" x2="${p}" y2="700" stroke="${road}" stroke-width="13" stroke-linecap="round"/>`).join('')}
    ${route?`<path d="M${you[0]} ${you[1]} L${you[0]} 410 L105 410 L105 270 L${friend[0]} 270 L${friend[0]} ${friend[1]}" fill="none" stroke="#7C5CFC" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="14 11" opacity=".9"><animate attributeName="stroke-dashoffset" from="50" to="0" dur="1.1s" repeatCount="indefinite"/></path>`:''}
    ${others.map(([x,y,i,c])=>`<g transform="translate(${x},${y})"><circle r="19" fill="${c}" opacity=".18"/><circle r="14" fill="${c}" stroke="#fff" stroke-width="3"/><text y="4.5" text-anchor="middle" font-size="12" font-weight="800" fill="#fff" font-family="Inter">${i}</text></g>`).join('')}
    <g transform="translate(${friend[0]},${friend[1]})"><circle r="24" fill="#35E1C8" opacity=".2"><animate attributeName="r" values="18;30;18" dur="2.4s" repeatCount="indefinite"/></circle><circle r="16" fill="#35E1C8" stroke="#fff" stroke-width="3.4"/><text y="5" text-anchor="middle" font-size="13" font-weight="800" fill="#04241D" font-family="Inter">P</text></g>
    <g transform="translate(${you[0]},${you[1]})"><circle r="30" fill="#7C5CFC" opacity=".16"><animate attributeName="r" values="22;38;22" dur="2.6s" repeatCount="indefinite"/></circle><circle r="17" fill="#7C5CFC" stroke="#fff" stroke-width="3.6"/><path d="M0 -7 L5 5 L0 2 L-5 5 Z" fill="#fff"/></g>
  </svg>`;
}

/* =================== 20. Track Friends map =================== */
reg('track','Track Friends','Track Friends Map',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">
  <div style="position:absolute;inset:0">${mapSvg({others:[[95,560,'J','#FFB84D'],[300,330,'R','#FF6E7F']]})}</div>
  ${statusbar()}
  <div style="position:absolute;top:56px;left:18px;right:18px;z-index:10">
    <div class="glass tight between">
      <div class="row" style="gap:10px"><span style="width:9px;height:9px;border-radius:9px;background:var(--cyan);box-shadow:0 0 0 4px rgba(53,225,200,.25)"></span>
      <div><div style="font-size:13px;font-weight:800">Sharing with 2 friends</div><p class="p" style="font-size:11px">Ends automatically in 1 h 42 m</p></div></div>
      <button class="pill" onclick="go('locperm')">Manage</button>
    </div>
  </div>
  <div style="position:absolute;left:0;right:0;bottom:96px;z-index:10;background:var(--glass);backdrop-filter:blur(28px);border:1px solid var(--border);border-bottom:0;border-radius:30px 30px 0 0;padding:12px 20px 20px">
    <div class="grab"></div>
    <div class="between"><h2 style="font-family:var(--disp);font-size:20px;margin:0;letter-spacing:-.01em;font-weight:700">Track Friends</h2><span class="pill" style="color:var(--violet)">Consent required</span></div>
    <div class="row" style="gap:9px;margin:14px 0 4px">
      <button class="btn sm" style="flex:1;height:46px" onclick="go('friendselect')">${ic('pin','#fff',16,2.2)} Start track</button>
      <button class="btn sm sec" style="flex:1;height:46px" onclick="toast('Live location shared for 1 hour.','pin','#7C5CFC')">Share my location</button>
      <button class="btn sm sec" style="height:46px;padding:0 14px" onclick="go('tracklimit')">Join</button>
    </div>
    <div class="list" style="margin-top:12px;background:var(--glass2)">
      ${[['Priya','400 m away · Library','P','#35E1C8'],['Jordan','1.2 km · Hostel B','J','#FFB84D'],['Rhea','Sharing paused','R','#FF6E7F']].map(([n,s,i,c])=>
      `<div class="item" onclick="go('activetrack')" style="padding:11px 14px"><div>${av(i,c,34,13)}</div><div class="col"><div class="t" style="font-size:13.5px">${n}</div><div class="s">${s}</div></div>${ic('chev','var(--muted)',16)}</div>`).join('')}
    </div>
  </div>
  ${tabbar('track')}
</div>`);

/* =================== 21. Friend selection & location consent =================== */
reg('friendselect','Track Friends','Friend Selection & Consent',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Start a track',{back:true,sub:'A temporary session that expires on its own.'})}
    <div class="glass stack">
      <div class="field" style="background:var(--glass2)"><div class="col"><label>What's this for?</label><input value="Meet at the quad"></div></div>
      <div><p class="eyebrow" style="margin-bottom:9px">Ends after</p><div class="row" style="gap:7px">${['30 min','1 hour','2 hours','Until I stop'].map((t,i)=>`<span class="pill ${i===2?'on':''}" onclick="this.parentNode.querySelectorAll('.pill').forEach(p=>p.classList.remove('on'));this.classList.add('on')">${t}</span>`).join('')}</div></div>
    </div>
    <div class="between" style="margin:22px 2px 10px"><h3 class="section-title" style="margin:0">Choose friends</h3><span class="pill">3 of 5 picked</span></div>
    <div class="list">
      ${[['Priya S','Nearby now','P','#35E1C8',1],['Jordan K','Active 2 min ago','J','#FFB84D',1],['Rhea N','Active 20 min ago','R','#FF6E7F',1],['Divya P','Last seen yesterday','D','#7C5CFC',0],['Sam K','Active now','S','#9B7BFF',0]].map(([n,s,i,c,on])=>
      `<div class="item" onclick="chk(this)">
        <div>${av(i,c,38,14)}</div><div class="col"><div class="t">${n}</div><div class="s">${s}</div></div>
        <div class="chk ${on?'yes':''}" style="width:24px;height:24px;border-radius:50%;border:2px solid ${on?'transparent':'var(--border)'};display:grid;place-items:center;flex:0 0 24px;${on?'background:linear-gradient(135deg,#7C5CFC,#35E1C8)':''}">${on?ic('check','#fff',13,3.2):''}</div>
      </div>`).join('')}
    </div>
    <div class="glass" style="margin-top:14px;background:rgba(124,92,252,.1);border:0">
      <div class="row" style="gap:10px;align-items:flex-start">
        ${ic('shield','var(--violet)',18,2.2)}
        <div><div style="font-size:13px;font-weight:800">Everyone must explicitly consent</div>
        <p class="p" style="font-size:12px;margin-top:4px">Friends get a request and choose to accept. Nobody is added to a track without saying yes.</p></div>
      </div>
    </div>
    <button class="btn" style="margin-top:14px" onclick="go('consent')">Send track request</button>
    <p class="p" style="text-align:center;font-size:11.5px;margin-top:12px">Maximum 5 people per session.</p>
  </div>
</div>`);

reg('consent','Track Friends','Location Consent',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body" style="text-align:center">
    <div style="width:78px;height:78px;border-radius:26px;background:rgba(124,92,252,.16);border:1px solid var(--border);display:grid;place-items:center;margin:24px auto 18px">${ic('pin','var(--violet)',34,2)}</div>
    <h2 style="font-family:var(--disp);font-size:22px;letter-spacing:-.01em;margin:0;font-weight:700">Share your live location?</h2>
    <p class="p" style="margin:10px 0 20px;padding:0 10px">Priya, Jordan and Rhea will see your position and distance until the session ends. You can stop any time.</p>
    <div class="glass" style="text-align:left">
      ${[['Who sees it','Only the 3 people in this track'],['How long','Up to 2 hours, then it expires'],['What they see','Live position + distance, not your history']].map(([k,v])=>
      `<div class="row" style="gap:11px;padding:10px 0;border-bottom:1px solid var(--hair)">${ic('check','var(--cyan)',16,2.4)}<div><div style="font-size:12.5px;font-weight:700">${k}</div><div style="font-size:11.5px;color:var(--muted)">${v}</div></div></div>`).join('')}
    </div>
    <div class="stack" style="margin-top:20px">
      <button class="btn" onclick="go('activetrack')">I consent — start sharing</button>
      <button class="btn line" onclick="back()">Not right now</button>
    </div>
  </div>
</div>`);

/* =================== 22. Active track (live tracking) =================== */
reg('activetrack','Track Friends','Active Track',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">
  <div style="position:absolute;inset:0">${mapSvg({route:true,you:[196,530],friend:[250,190],others:[[105,340,'J','#FFB84D']]})}</div>
  ${statusbar()}
  <div style="position:absolute;top:56px;left:18px;right:18px;z-index:10">
    <div class="glass tight row" style="gap:11px">
      <button class="iconbtn ghost" onclick="back()">${ic('back','currentColor',18)}</button>
      <div style="flex:1"><div style="font-size:13.5px;font-weight:800">Meet at the quad</div><p class="p" style="font-size:11px">3 people · ends in 1 h 38 m</p></div>
      <span class="pill cyan">Live</span>
    </div>
  </div>
  <div style="position:absolute;top:118px;left:18px;right:18px;z-index:10">
    <div class="glass tight row" style="gap:11px;background:linear-gradient(135deg,var(--violet),#9B7BFF);border:0;color:#fff">
      <div style="width:30px;height:30px;border-radius:11px;background:rgba(255,255,255,.22);display:grid;place-items:center">${ic('nav','#fff',16,2.3)}</div>
      <div style="flex:1"><div style="font-size:13.5px;font-weight:800">You're getting closer</div><p style="font-size:11.5px;opacity:.85;margin:2px 0 0">Head north past the canteen, then turn right.</p></div>
    </div>
  </div>
  <div style="position:absolute;left:0;right:0;bottom:96px;z-index:10;background:var(--glass);backdrop-filter:blur(28px);border:1px solid var(--border);border-bottom:0;border-radius:30px 30px 0 0;padding:12px 20px 20px">
    <div class="grab"></div>
    <div class="row" style="gap:13px">
      <div style="position:relative">${av('P','#35E1C8',50,19)}<span style="position:absolute;bottom:1px;right:1px;width:13px;height:13px;border-radius:13px;background:var(--cyan);border:2.5px solid var(--bg)"></span></div>
      <div style="flex:1"><div style="font-family:var(--disp);font-size:18px;letter-spacing:-.01em;font-weight:700">Priya is nearby</div><p class="p" style="font-size:12px">Waiting near the notice board</p></div>
      <div style="text-align:right"><div class="big" style="font-size:21px">180 m</div><p class="p" style="font-size:11px;margin-top:2px">~2 min walk</p></div>
    </div>
    <div class="row" style="gap:6px;margin:16px 0 4px">
      ${[['Started',1],['Getting closer',1],['Nearby',1],['Reached',0]].map(([t,done])=>
      `<div style="flex:1;text-align:center"><div style="height:5px;border-radius:5px;background:${done?'var(--violet)':'var(--glass2)'}"></div><div style="font-size:8.5px;font-weight:700;color:${done?'var(--violet)':'var(--muted)'};margin-top:6px">${t}</div></div>`).join('')}
    </div>
    <div class="row" style="gap:9px;margin-top:14px">
      <button class="btn sm sec" style="flex:1;height:46px" onclick="go('chat1')">${ic('chat','currentColor',16,2.1)} Message</button>
      <button class="btn sm cyan" style="flex:1;height:46px" onclick="go('trackdone')">We met 🎉</button>
      <button class="btn sm sec" style="height:46px;padding:0 14px;color:#FF4D5E" onclick="endTrackConfirm()">End</button>
    </div>
  </div>
  ${tabbar('track')}
</div>`);

/* =================== 23. Track completed =================== */
reg('trackdone','Track Friends','Track Completed',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column;background:radial-gradient(120% 90% at 30% 10%,#173B3E,#0A0E1E 65%);color:#fff">
  ${statusbar()}
  <div class="body" style="display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;color:#fff">
    <div style="position:relative;width:180px;height:180px;display:grid;place-items:center">
      ${[0,1,2].map(i=>`<div style="position:absolute;inset:${i*22}px;border-radius:50%;border:1.5px solid rgba(255,255,255,.22);animation:ring 2.4s ${i*.3}s infinite ease-out"></div>`).join('')}
      <div style="display:flex">
        <div style="border:3px solid #173B3E;border-radius:50%">${av('A','#7C5CFC',62,23)}</div>
        <div style="margin-left:-16px;border:3px solid #173B3E;border-radius:50%">${av('P','#35E1C8',62,23)}</div>
      </div>
      <div style="position:absolute;bottom:6px;width:38px;height:38px;border-radius:50%;background:#fff;display:grid;place-items:center;animation:pin .5s .25s backwards cubic-bezier(.32,.72,0,1)">${ic('check','#0E9E7A',20,3.2)}</div>
    </div>
    <h2 style="font-family:var(--disp);font-size:29px;letter-spacing:-.015em;margin:22px 0 0;font-weight:700">You're together!</h2>
    <p style="font-size:14px;opacity:.8;margin:10px 0 0">Track completed at the quad · 4:12 PM</p>
    <div style="display:flex;gap:10px;margin-top:26px;width:100%">
      ${[['Walked','640 m'],['Took','7 min'],['Friends','2']].map(([k,v])=>
      `<div style="flex:1;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:20px;padding:15px 8px"><div style="font-family:var(--disp);font-size:18px;font-weight:700">${v}</div><div style="font-size:10.5px;opacity:.65;font-weight:700;margin-top:3px">${k}</div></div>`).join('')}
    </div>
    <div class="stack" style="width:100%;margin-top:22px">
      <button class="btn cyan" onclick="go('track')">End track</button>
      <button class="btn line" style="border-color:rgba(255,255,255,.22);color:#fff" onclick="go('diary-new')">Save this to my diary</button>
    </div>
    <p style="font-size:11.5px;opacity:.6;margin-top:16px">Location sharing has stopped for everyone in this session.</p>
    <style>@keyframes ring{0%{transform:scale(.7);opacity:.7}100%{transform:scale(1.25);opacity:0}}</style>
  </div>
</div>`);

/* =================== 24. Track limit error =================== */
reg('tracklimit','Track Friends','Track Limit Error',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">
  <div style="position:absolute;inset:0;opacity:.4;filter:saturate(.5)">${mapSvg({others:[[95,560,'J','#FFB84D'],[300,330,'R','#FF6E7F']]})}</div>
  ${statusbar()}
  <div class="scrim" style="position:absolute"></div>
  <div class="modal">
    <div style="width:58px;height:58px;border-radius:20px;background:rgba(255,184,77,.18);display:grid;place-items:center;margin:0 auto 14px">${ic('alert','#FFB84D',26,2.2)}</div>
    <div class="h3" style="font-size:19px">Track limit reached</div>
    <p class="p" style="margin:9px 0 16px;font-size:13px">A maximum of 5 people can join this session. "Meet at the quad" is full.</p>
    <div class="list" style="background:var(--glass2);text-align:left;margin-bottom:16px">
      <div class="item" style="padding:11px 14px">
        <div style="display:flex">${[['A','#7C5CFC'],['P','#35E1C8'],['J','#FFB84D'],['R','#FF6E7F'],['D','#9B7BFF']].map(([i,c],n)=>`<div style="margin-left:${n?'-10px':'0'};border:2.5px solid var(--glass2);border-radius:50%">${av(i,c,28,10)}</div>`).join('')}</div>
        <div class="col"><div class="t" style="font-size:12.5px">5 of 5 joined</div><div class="s">Session is full</div></div>
      </div>
    </div>
    <button class="btn" onclick="go('friendselect')">Start a new track</button>
    <button class="btn sec" style="margin-top:8px" onclick="go('track')">Back to map</button>
  </div>
  ${tabbar('track')}
</div>`);

/* =================== location permissions =================== */
reg('locperm','Track Friends','Location Permissions',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Location sharing',{back:true})}
    <div class="glass" style="background:linear-gradient(135deg,var(--violet),#9B7BFF);border:0;color:#fff">
      <div class="between"><span class="pill" style="background:rgba(255,255,255,.2);color:#fff">Sharing is on</span>${ic('pin','#fff',19,2.2)}</div>
      <div style="font-family:var(--disp);font-size:19px;letter-spacing:-.01em;margin:12px 0 4px;font-weight:700">2 people can see you right now</div>
      <p style="font-size:12.5px;opacity:.85;margin:0">Session "Meet at the quad" ends automatically in 1 h 38 m.</p>
      <button class="btn sm" style="width:100%;margin-top:14px;background:#fff;color:var(--violet);box-shadow:none" onclick="toast('Location sharing stopped for everyone.','check')">Stop sharing now</button>
    </div>
    <h3 class="section-title">Who can see you</h3>
    <div class="list">
      ${[['Priya S','Live, until 6:20 PM','P','#35E1C8',1],['Jordan K','Live, until 6:20 PM','J','#FFB84D',1],['Rhea N','Not sharing','R','#FF6E7F',0]].map(([n,s,i,c,on])=>
      `<div class="item"><div>${av(i,c,38,14)}</div><div class="col"><div class="t">${n}</div><div class="s">${s}</div></div><div class="switch ${on?'on':''}" onclick="tog(this)"></div></div>`).join('')}
    </div>
    <h3 class="section-title">Rules</h3>
    <div class="list">
      ${[['Sessions expire on their own','Nothing keeps running by accident',1],['Ask before anyone can add me','No surprise tracks',1],['Show a banner while sharing','So you always know it\'s on',1]].map(([t,s,on])=>
      `<div class="item"><div class="col"><div class="t">${t}</div><div class="s" style="white-space:normal">${s}</div></div><div class="switch ${on?'on':''}" onclick="tog(this)"></div></div>`).join('')}
    </div>
    <p class="p" style="text-align:center;font-size:11.5px;margin-top:14px">Your location is never public and never sold.</p>
  </div>
</div>`);

/* =================== 25. Diary Home =================== */
reg('diary','My Diary','Diary Home',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body tabbed">
    ${nav('My Diary',{right:`<button class="iconbtn" onclick="go('diary-lock')">${ic('lock','currentColor',18)}</button><button class="iconbtn" style="background:linear-gradient(135deg,var(--violet),var(--cyan))" onclick="go('diary-new')">${ic('plus','#fff',19,2.4)}</button>`,sub:'Unlimited pages · private by default'})}
    <div class="glass">
      <div class="between" style="margin-bottom:12px"><div class="h3" style="font-size:15px">June 2026</div><div class="row" style="gap:12px">${ic('back','var(--muted)',16)}${ic('chev','var(--muted)',16)}</div></div>
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:6px;text-align:center">
        ${['M','T','W','T','F','S','S'].map(d=>`<div style="font-size:10px;font-weight:800;color:var(--muted)">${d}</div>`).join('')}
        ${Array.from({length:30},(_,i)=>{const d=i+1;const moods={2:'🙂',3:'😄',5:'😐',8:'🙂',9:'😔',11:'😄',12:'🙂',15:'😣',16:'🙂',18:'😄',19:'🙂',22:'😐',23:'🙂',25:'😄',26:'🙂'};
          const sel=d===26; return `<div style="aspect-ratio:1;border-radius:11px;display:grid;place-items:center;font-size:${moods[d]?'14px':'11.5px'};font-weight:700;background:${sel?'linear-gradient(135deg,var(--violet),var(--cyan))':moods[d]?'var(--glass2)':'transparent'};color:${sel?'#fff':moods[d]?'var(--text)':'var(--muted)'};cursor:pointer" onclick="${moods[d]?"go('diary-entry')":''}">${moods[d]||d}</div>`}).join('')}
      </div>
    </div>
    <div class="field" style="margin-top:14px">${ic('search','var(--muted)',18)}<input placeholder="Search your entries…"></div>
    <div class="chips" style="margin-top:12px">${['All','Favourites','With photos','Gratitude','Travel'].map((t,i)=>`<span class="pill ${i?'':'on'}">${t}</span>`).join('')}</div>

    <h3 class="section-title">Recent pages</h3>
    <div class="stack">
      <div class="glass" onclick="go('diary-entry')" style="cursor:pointer;background:linear-gradient(135deg,rgba(124,92,252,.16),rgba(53,225,200,.1));border:0">
        <div class="between"><span class="pill on">Fri · 26 June</span><span style="font-size:19px">😄</span></div>
        <div style="font-family:var(--disp);font-size:17px;letter-spacing:-.01em;margin:11px 0 6px;font-weight:700">Golden hour on the quad</div>
        <p style="font-size:13px;line-height:1.55;color:var(--muted);margin:0">Sat outside AB2 with Priya until the sky went orange. Didn't open a single textbook and it was still a good day…</p>
        <div class="row" style="gap:7px;margin-top:13px">
          ${['#7C5CFC33','#35E1C833','#FFB84D33'].map(c=>`<div style="width:44px;height:44px;border-radius:13px;background:${c}"></div>`).join('')}
          <span style="font-size:11px;font-weight:700;color:var(--muted);margin-left:4px">2 photos</span><span style="margin-left:auto">${ic('heart','#FF6E7F',17,2.2)}</span>
        </div>
      </div>
      ${[['Wed · 24 June','😐','Two assignments, one brain','Wrote out the plan NEXORA suggested. Finished the intro section at least.'],
         ['Mon · 22 June','🙂','Gratitude page','A free hour in the library. Mom\'s call. The tree outside AB2.']].map(([d,e,t,p])=>
      `<div class="glass" onclick="go('diary-entry')" style="cursor:pointer">
        <div class="between"><span class="pill">${d}</span><span style="font-size:18px">${e}</span></div>
        <div style="font-family:var(--disp);font-size:16px;letter-spacing:-.01em;margin:10px 0 5px;font-weight:700">${t}</div>
        <p class="p" style="font-size:12.5px">${p}</p>
      </div>`).join('')}
    </div>

    <div class="glass" style="margin-top:14px;background:rgba(124,92,252,.1);border:0">
      <div class="row" style="gap:9px;margin-bottom:10px">${ic('spark','var(--violet)',16,2.2)}<p class="eyebrow" style="color:var(--violet)">Want to decorate today's page?</p></div>
      <div class="stack" style="gap:8px">
        ${['Try a gratitude prompt','Write about your favourite moment today','Create a goals page','Build a mood board'].map(t=>
        `<div class="row" style="background:var(--glass2);padding:10px 12px;border-radius:13px;gap:9px;cursor:pointer" onclick="go('diary-new')"><span style="font-size:12.5px;font-weight:600;flex:1">${t}</span>${ic('chev','var(--violet)',15)}</div>`).join('')}
      </div>
    </div>
  </div>
  ${tabbar('diary')}
</div>`);

/* =================== 26. Create/customize diary entry =================== */
reg('diary-new','My Diary','Create + Customize Entry',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column;background:radial-gradient(120% 90% at 30% 0%,#241B57,#0A0E1E 60%)">
  ${statusbar()}
  <div class="body">
    <div class="navbar">
      <button class="iconbtn" onclick="back()">${ic('back','currentColor',19)}</button>
      <div style="flex:1;text-align:center"><div style="font-size:12.5px;font-weight:800">Friday, 26 June</div><div style="font-size:10.5px;opacity:.55;font-weight:600">Saved a moment ago</div></div>
      <button class="btn sm" style="background:linear-gradient(135deg,var(--violet),var(--cyan))" onclick="toast('Entry saved.','book','#7C5CFC');setTimeout(()=>go('diary-entry',true),700)">Save</button>
    </div>
    <div class="row" style="gap:7px;justify-content:center;margin-bottom:16px">
      ${['😄','🙂','😐','😔','😣'].map((e,i)=>`<div style="width:46px;height:46px;border-radius:16px;background:${i?'var(--glass2)':'linear-gradient(135deg,var(--violet),var(--cyan))'};display:grid;place-items:center;font-size:21px;cursor:pointer">${e}</div>`).join('')}
    </div>
    <div class="glass">
      <input placeholder="Give this page a title…" value="Golden hour on the quad" style="width:100%;border:0;background:none;outline:none;font:700 18px/1.5 var(--disp);color:var(--text);letter-spacing:-.01em">
      <textarea rows="8" style="width:100%;border:0;background:none;outline:none;resize:none;font:500 14px/1.9 var(--sans);color:var(--text);margin-top:6px" placeholder="Start anywhere. Nobody else reads this.">Sat outside AB2 with Priya until the sky went orange. Didn't open a single textbook and it was still a good day.</textarea>
      <div class="row" style="gap:8px;margin-top:6px">
        ${['#7C5CFC33','#35E1C833'].map(c=>`<div style="width:62px;height:62px;border-radius:16px;background:${c};position:relative"><span style="position:absolute;top:-5px;right:-5px;width:19px;height:19px;border-radius:19px;background:var(--text);color:var(--bg);font-size:11px;display:grid;place-items:center">×</span></div>`).join('')}
        <div style="width:62px;height:62px;border-radius:16px;border:1.5px dashed var(--border);display:grid;place-items:center">${ic('plus','var(--violet)',20,2.3)}</div>
      </div>
      <div class="row" style="gap:6px;margin-top:14px">${['🌇','📚','🫶'].map(s=>`<span style="font-size:20px">${s}</span>`).join('')}<span style="font-size:11.5px;font-weight:700;opacity:.5;margin-left:4px">3 stickers</span></div>
    </div>
    <div class="row" style="gap:7px;overflow-x:auto;margin-top:16px;padding-bottom:4px">
      ${[['image','Photo'],['paint','Doodle'],['star','Sticker'],['book','Quote'],['grid','Template']].map(([i,l])=>
      `<button class="glass tight" style="display:flex;flex-direction:column;align-items:center;gap:5px;min-width:68px" onclick="go('diary-style')">${ic(i,'var(--violet)',18,2.1)}<span style="font-size:10.5px;font-weight:700">${l}</span></button>`).join('')}
    </div>
    <div class="glass" style="margin-top:16px;background:rgba(124,92,252,.1);border:0">
      <div class="row" style="gap:9px;margin-bottom:9px">${ic('spark','var(--violet)',15,2.2)}<p class="eyebrow" style="color:var(--violet)">NEXORA suggests</p></div>
      <p class="p" style="font-size:12.5px">Want a "small good things" page to collect moments like this one?</p>
      <div class="row" style="gap:7px;margin-top:11px"><button class="pill on">Use that layout</button><button class="pill">Not now</button></div>
    </div>
  </div>
</div>`);

/* =================== 27. Diary customization (style picker) =================== */
reg('diary-style','My Diary','Diary Customization',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Make it yours',{back:true,right:`<button class="btn sm" style="background:linear-gradient(135deg,var(--violet),var(--cyan))" onclick="toast('Style applied.','paint','#7C5CFC');setTimeout(back,600)">Apply</button>`})}
    <div class="glass" style="background:radial-gradient(120% 90% at 30% 0%,#241B57,#0A0E1E 60%)">
      <div style="font-family:var(--disp);font-size:16px;letter-spacing:-.01em;font-weight:700">Preview of your page</div>
      <p style="font-size:12.5px;line-height:1.8;color:var(--muted);margin:4px 0 0">This is how your writing space will look with the current theme.</p>
    </div>
    <h3 class="section-title">Page background</h3>
    <div class="row" style="gap:9px;overflow-x:auto;padding-bottom:4px">
      ${[['Nebula','radial-gradient(circle,#3A2B7A,#0A0E1E)',1],['Aurora','linear-gradient(135deg,#0F3B3E,#0A0E1E)',0],['Sunset','linear-gradient(135deg,#4A2B3E,#241B2E)',0],['Paper','linear-gradient(135deg,#EEEBFA,#F8F6FF)',0]].map(([n,bg,on])=>
      `<div style="min-width:78px;text-align:center"><div style="height:92px;border-radius:16px;background:${bg};border:2.5px solid ${on?'var(--violet)':'transparent'}"></div><div style="font-size:10.5px;font-weight:700;margin-top:7px;color:${on?'var(--violet)':'var(--muted)'}">${n}</div></div>`).join('')}
    </div>
    <h3 class="section-title">Accent colour</h3>
    <div class="row" style="gap:10px">${['#7C5CFC','#35E1C8','#FFB84D','#FF6E7F','#9B7BFF'].map((c,i)=>`<div style="width:42px;height:42px;border-radius:15px;background:${c};box-shadow:${i===0?'0 0 0 3px var(--bg),0 0 0 5.5px '+c:'none'}"></div>`).join('')}</div>
    <h3 class="section-title">Stickers &amp; frames</h3>
    <div style="display:grid;grid-template-columns:repeat(6,1fr);gap:9px">
      ${['🌇','☕','🫶','🌿','✨','📚','🎧','🌙','🍜','🐾','🎈','💌'].map(s=>`<div class="glass" style="padding:0;aspect-ratio:1;display:grid;place-items:center;font-size:19px">${s}</div>`).join('')}
    </div>
    <h3 class="section-title">Templates</h3>
    <div class="grid2">
      ${[['Gratitude','Three good things','#35E1C8'],['Travel page','Photos + captions','#FFB84D'],['Goals','Month at a glance','#7C5CFC'],['Birthday/event','Celebration layout','#FF6E7F']].map(([t,s,c])=>
      `<div class="glass tight" style="border-left:3px solid ${c}"><div style="font-size:13.5px;font-weight:800">${t}</div><p class="p" style="font-size:11.5px;margin-top:3px">${s}</p></div>`).join('')}
    </div>
  </div>
</div>`);

/* =================== 28. Diary entry view =================== */
reg('diary-entry','My Diary','Diary Entry View',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column;background:radial-gradient(120% 90% at 30% 0%,#241B57,#0A0E1E 60%)">
  ${statusbar()}
  <div class="body">
    <div class="navbar">
      <button class="iconbtn" onclick="back()">${ic('back','currentColor',19)}</button><div style="flex:1"></div>
      <button class="iconbtn" onclick="toast('Added to favourites.','heart','#FF6E7F')">${ic('heart','#FF6E7F',18,2.2)}</button>
      <button class="iconbtn" onclick="go('diary-options')">${ic('grid','currentColor',18)}</button>
    </div>
    <div class="glass">
      <div class="between"><span class="pill on">Friday · 26 June 2026</span><span style="font-size:24px">😄</span></div>
      <h1 style="font-family:var(--disp);font-size:22px;letter-spacing:-.015em;line-height:1.25;margin:14px 0 12px;font-weight:700">Golden hour on the quad</h1>
      <p style="font-size:14px;line-height:1.9;color:var(--muted);margin:0">Sat outside AB2 with Priya until the sky went orange. Didn't open a single textbook and it was still a good day.</p>
      <p style="font-size:14px;line-height:1.9;color:var(--muted);margin:14px 0 0">I keep forgetting the good parts of this year are mostly like this — unplanned and twenty minutes long.</p>
      <div style="display:grid;grid-template-columns:2fr 1fr;gap:9px;margin-top:18px">
        <div style="height:130px;border-radius:18px;background:linear-gradient(135deg,#FFB84D,#FF6E7F)"></div>
        <div style="display:grid;gap:9px"><div style="border-radius:18px;background:linear-gradient(135deg,#7C5CFC,#9B7BFF)"></div><div style="border-radius:18px;background:linear-gradient(135deg,#35E1C8,#57F0D8)"></div></div>
      </div>
      <div class="row" style="gap:6px;margin-top:16px;padding-top:14px;border-top:1px solid var(--hair)">
        <span style="font-size:19px">🌇</span><span style="font-size:19px">📚</span><span style="font-size:19px">🫶</span>
        <span style="font-size:11.5px;font-weight:700;color:var(--muted);margin-left:auto">312 words this week</span>
      </div>
    </div>
    <div class="row" style="gap:9px;margin-top:16px">
      <button class="btn sm sec" style="flex:1;height:46px" onclick="go('diary-new')">${ic('paint','currentColor',16,2.1)} Edit</button>
      <button class="btn sm sec" style="flex:1;height:46px" onclick="toast('Shared as an image.','share','#7C5CFC')">${ic('share','currentColor',16,2.1)} Share</button>
    </div>
  </div>
</div>`);

reg('diary-options','My Diary','Entry Options',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('This page',{back:true})}
    <div class="list">
      <div class="item" onclick="toast('Exported as an image.','share','#7C5CFC')"><div class="sqico" style="background:rgba(124,92,252,.2)">${ic('share','var(--violet)',17,2.1)}</div><div class="col"><div class="t">Export as image</div><div class="s">Share just this page</div></div></div>
      <div class="item" onclick="go('diary-style')"><div class="sqico" style="background:rgba(155,123,255,.2)">${ic('paint','#9B7BFF',17,2.1)}</div><div class="col"><div class="t">Change page style</div></div></div>
      <div class="item" onclick="confirmDeleteEntry()"><div class="sqico" style="background:rgba(255,110,127,.18)">${ic('trash','#FF6E7F',17,2.1)}</div><div class="col"><div class="t" style="color:#FF6E7F">Delete entry</div></div></div>
    </div>
  </div>
</div>`);

/* =================== diary lock =================== */
reg('diary-lock','My Diary','Diary Lock (Face ID)',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column;background:radial-gradient(120% 90% at 30% 0%,#241B57,#0A0E1E 65%)">
  ${statusbar()}
  <div class="body" style="display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center">
    <div style="width:92px;height:92px;border-radius:32px;background:rgba(124,92,252,.18);display:grid;place-items:center;animation:pin .45s cubic-bezier(.32,.72,0,1)">${ic('lock','#9B7BFF',40,2)}</div>
    <h2 style="font-family:var(--disp);font-size:24px;letter-spacing:-.01em;margin:22px 0 0;font-weight:700">Your diary is private</h2>
    <p class="p" style="margin:10px 0 0;max-width:280px;line-height:1.55">Entries are protected on your device. Unlock with Face ID to read or write.</p>
    <button class="btn" style="margin-top:34px" onclick="go('diary',true)">${ic('fingerprint','#fff',18,2.2)} Unlock with Face ID</button>
    <button class="btn line" style="margin-top:10px" onclick="go('diary',true)">Use passcode instead</button>
  </div>
</div>`);

/* =================== 29. Chats list =================== */
reg('chats','Chats','Chat List',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body tabbed">
    ${nav('Chats',{right:`<button class="iconbtn" style="background:linear-gradient(135deg,var(--violet),var(--cyan))" onclick="toast('Pick a friend to start a chat.','chat','#7C5CFC')">${ic('plus','#fff',19,2.4)}</button>`})}
    <div class="field">${ic('search','var(--muted)',18)}<input placeholder="Search friends and groups"></div>
    <div class="chips" style="margin:14px -20px 4px;padding:0 20px 6px">${['Friends','College','Events','Study groups'].map((t,i)=>`<span class="pill ${i?'':'on'}">${t}</span>`).join('')}</div>
    <div class="row" style="gap:12px;overflow-x:auto;margin:10px -20px 4px;padding:0 20px 6px">
      ${[['P','#35E1C8','Priya',1],['J','#FFB84D','Jordan',1],['R','#FF6E7F','Rhea',0],['D','#7C5CFC','Divya',1],['S','#9B7BFF','Sam',0]].map(([i,c,n,on])=>
      `<div style="text-align:center;min-width:56px" onclick="go('chat1')"><div style="position:relative;display:inline-block">${av(i,c,52,19)}${on?'<span style="position:absolute;bottom:1px;right:1px;width:14px;height:14px;border-radius:14px;background:var(--cyan);border:2.5px solid var(--bg)"></span>':''}</div><div style="font-size:10.5px;font-weight:700;margin-top:6px;color:var(--muted)">${n}</div></div>`).join('')}
    </div>
    <h3 class="section-title">Recent</h3>
    <div class="list">
      ${[['Study Group — DS','Jordan: I\'ll book the room at 7','SG','linear-gradient(135deg,#FF6E7F,#9B7BFF)','2 min',3,'group'],
         ['Priya S','See you at the quad!','P','#35E1C8','9 min',1,'chat1'],
         ['Event Planning','NEXORA AI summarized 46 messages','EP','linear-gradient(135deg,#7C5CFC,#35E1C8)','1 h',0,'group'],
         ['Jordan K','Voice message · 0:34','J','#FFB84D','3 h',0,'chat1'],
         ['Rhea N','Sent the notes 📚','R','#FF6E7F','Yesterday',0,'chat1']].map(([n,m,i,c,t,unread,to])=>
      `<div class="item" onclick="go('${to}')"><div>${av(i,c,46,i.length>1?14:17)}</div>
        <div class="col"><div class="t">${n}</div><div class="s">${m}</div></div>
        <div style="text-align:right;flex:0 0 auto"><div style="font-size:11px;color:var(--muted);font-weight:700">${t}</div>${unread?`<div style="margin-top:5px;min-width:20px;height:20px;border-radius:20px;background:linear-gradient(135deg,var(--violet),var(--cyan));color:#fff;font-size:11px;font-weight:800;display:grid;place-items:center;padding:0 6px">${unread}</div>`:''}</div>
      </div>`).join('')}
    </div>
    <div class="glass" style="margin-top:14px;background:rgba(124,92,252,.12);border:0" onclick="go('groupai')">
      <div class="row" style="gap:10px"><div class="sqico" style="background:linear-gradient(135deg,var(--violet),var(--cyan))">${ic('spark','#fff',17,2.2)}</div>
      <div style="flex:1"><div style="font-size:13.5px;font-weight:800">Catch up in seconds</div><p class="p" style="font-size:11.5px">Ask AI can summarise any group you've missed.</p></div>${ic('chev','var(--violet)',17)}</div>
    </div>
  </div>
  ${tabbar('chats')}
</div>`);

/* =================== 30. Individual chat =================== */
reg('chat1','Chats','Individual Chat',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div style="padding:0 16px 12px;border-bottom:1px solid var(--hair);position:relative;z-index:2">
    <div class="row" style="gap:11px">
      <button class="iconbtn ghost" onclick="back()">${ic('back','currentColor',19)}</button>
      <div>${av('P','#35E1C8',40,15)}</div>
      <div style="flex:1"><div style="font-size:15px;font-weight:800;letter-spacing:-.005em">Priya S</div><div style="font-size:11px;color:var(--cyan);font-weight:700">Active now</div></div>
      <button class="iconbtn" onclick="go('call-voice')">${ic('phone','currentColor',18)}</button>
      <button class="iconbtn" onclick="go('call-video')">${ic('video','currentColor',18)}</button>
    </div>
  </div>
  <div class="body" style="padding-top:16px">
    <p class="p" style="text-align:center;font-size:11px;margin-bottom:16px">Today</p>
    <div class="stack" style="gap:9px">
      <div class="glass tight" style="max-width:76%;border-radius:20px 20px 20px 6px;font-size:14px;line-height:1.5">Are you at the quad yet?</div>
      <div style="align-self:flex-end;max-width:76%;background:linear-gradient(135deg,var(--violet),#9B7BFF);color:#fff;padding:11px 14px;border-radius:20px 20px 6px 20px;font-size:14px;line-height:1.5;font-weight:500">On my way, 5 min out 🏃‍♀️</div>
      <div style="align-self:flex-end;max-width:62%"><div style="height:150px;border-radius:20px 20px 6px 20px;background:linear-gradient(135deg,#FFB84D,#FF6E7F)"></div></div>
      <div class="glass tight" style="max-width:76%;border-radius:20px 20px 20px 6px;font-size:14px;line-height:1.5">that sunset though 😍 send me the file?</div>
      <div style="align-self:flex-end;max-width:70%" class="glass tight" style="border-radius:20px 20px 6px 20px">
        <div class="row" style="gap:10px">${ic('mic','var(--violet)',18,2.2)}<div style="flex:1;display:flex;gap:2.5px;align-items:center;height:26px">${Array.from({length:24},(_,i)=>`<div style="flex:1;height:${8+Math.abs(Math.sin(i*1.3))*17}px;border-radius:3px;background:${i<10?'var(--violet)':'var(--glass2)'}"></div>`).join('')}</div><span style="font-size:11px;font-weight:700;color:var(--muted)">0:34</span></div>
      </div>
      <div style="align-self:flex-end;max-width:78%;background:linear-gradient(135deg,var(--violet),var(--cyan));color:#fff;padding:13px;border-radius:20px;box-shadow:var(--glow-v)" onclick="go('activetrack')">
        <div class="row" style="gap:10px">${ic('pin','#fff',19,2.2)}<div style="flex:1"><div style="font-size:13px;font-weight:800">Track request</div><div style="font-size:11.5px;opacity:.85;margin-top:2px">Meet at the quad · expires in 2 h</div></div></div>
        <button class="btn sm" style="width:100%;margin-top:11px;background:#fff;color:var(--violet);box-shadow:none">Join track</button>
      </div>
      <div class="glass tight" style="max-width:40%;border-radius:20px 20px 20px 6px;color:var(--muted)" class="dots"><span></span><span></span><span></span></div>
    </div>
  </div>
  <div style="padding:8px 14px 30px;background:var(--glass);backdrop-filter:var(--blur);border-top:1px solid var(--hair)">
    <div class="row" style="gap:8px">
      <button class="iconbtn">${ic('plus','currentColor',19,2.3)}</button>
      <div class="field" style="flex:1;padding:9px 12px"><input placeholder="Message"><span style="font-size:17px">😊</span></div>
      <button class="iconbtn" style="background:linear-gradient(135deg,var(--violet),var(--cyan));border:0">${ic('mic','#fff',18)}</button>
    </div>
  </div>
</div>`);

/* =================== 31. Group chat =================== */
reg('group','Chats','Group Chat',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div style="padding:0 16px 12px;border-bottom:1px solid var(--hair);position:relative;z-index:2">
    <div class="row" style="gap:11px">
      <button class="iconbtn ghost" onclick="back()">${ic('back','currentColor',19)}</button>
      <div>${av('SG','linear-gradient(135deg,#FF6E7F,#9B7BFF)',40,13)}</div>
      <div style="flex:1"><div style="font-size:15px;font-weight:800;letter-spacing:-.005em">Study Group — DS</div><div style="font-size:11px;color:var(--muted);font-weight:600">5 members · 3 online</div></div>
      <button class="iconbtn" style="background:linear-gradient(135deg,var(--violet),var(--cyan));border:0" onclick="go('groupai')">${ic('spark','#fff',18,2.3)}</button>
      <button class="iconbtn" onclick="go('call-video')">${ic('video','currentColor',18)}</button>
    </div>
  </div>
  <div class="body" style="padding-top:16px">
    <div class="glass tight row" style="gap:10px;background:rgba(124,92,252,.1);border:0;margin-bottom:16px" onclick="go('groupai')">
      <div class="sqico" style="background:linear-gradient(135deg,var(--violet),var(--cyan));width:30px;height:30px;flex:0 0 30px">${ic('spark','#fff',15,2.3)}</div>
      <div style="flex:1;font-size:12.5px;font-weight:700">46 new messages while you were away</div><span class="pill on">Ask AI</span>
    </div>
    <div class="stack" style="gap:12px">
      ${[['Jordan','J','#FFB84D','So are we meeting Saturday or Sunday??'],['Rhea','R','#FF6E7F','Saturday works, I have a viva Sunday morning 😭']].map(([n,i,c,m])=>
      `<div class="row" style="align-items:flex-end;gap:9px">${av(i,c,30,11)}<div><div style="font-size:10.5px;font-weight:700;color:var(--muted);margin-bottom:4px;padding-left:4px">${n}</div><div class="glass tight" style="max-width:250px;border-radius:18px 18px 18px 5px;font-size:14px;line-height:1.5">${m}</div></div></div>`).join('')}
      <div style="align-self:flex-end;max-width:76%;background:linear-gradient(135deg,var(--violet),#9B7BFF);color:#fff;padding:11px 14px;border-radius:18px 18px 5px 18px;font-size:14px;line-height:1.5;font-weight:500">Saturday 👍 let's lock it</div>
      <div class="glass" style="max-width:94%">
        <div class="row" style="gap:9px;margin-bottom:12px">${ic('poll','var(--violet)',16,2.3)}<span style="font-size:12.5px;font-weight:800">What time on Saturday?</span></div>
        ${[['6 PM',3,60],['8 PM',2,40],['After dinner',0,0]].map(([o,v,p])=>
        `<div style="margin-bottom:9px"><div class="between" style="margin-bottom:5px"><span style="font-size:12.5px;font-weight:700">${o}</span><span style="font-size:11.5px;color:var(--muted);font-weight:700">${v}</span></div><div class="bar" style="height:7px"><span style="width:${p}%;${p<50?'background:var(--glass2)':''}"></span></div></div>`).join('')}
        <p class="p" style="font-size:11px;margin-top:10px">5 of 5 voted · created by NEXORA AI</p>
      </div>
      <div style="align-self:center;background:var(--glass2);padding:7px 13px;border-radius:999px;font-size:11px;font-weight:700;color:var(--muted)" onclick="go('sharedgoal')">Alex shared a money plan · Trip fund</div>
    </div>
  </div>
  <div style="padding:8px 14px 30px;background:var(--glass);backdrop-filter:var(--blur);border-top:1px solid var(--hair)">
    <div class="chips" style="padding:0 0 9px;margin:0">${['Summarise','Make a poll','Plan the evening','Split expenses'].map(t=>`<span class="pill" onclick="go('groupai')">${ic('spark','currentColor',12,2.4)} ${t}</span>`).join('')}</div>
    <div class="row" style="gap:8px">
      <button class="iconbtn">${ic('plus','currentColor',19,2.3)}</button>
      <div class="field" style="flex:1;padding:9px 12px"><input placeholder="Message Study Group"><span style="font-size:17px">😊</span></div>
      <button class="iconbtn" style="background:linear-gradient(135deg,var(--violet),var(--cyan));border:0">${ic('mic','#fff',18)}</button>
    </div>
  </div>
</div>`);

/* =================== 32. AI group assistant =================== */
reg('groupai','Chats','AI Group Assistant',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    <div class="navbar">
      <button class="iconbtn" onclick="back()">${ic('back','currentColor',19)}</button>
      <div style="flex:1"><div class="row" style="gap:8px"><div style="width:26px;height:26px;border-radius:9px;background:linear-gradient(135deg,var(--violet),var(--cyan));display:grid;place-items:center">${ic('spark','#fff',14,2.3)}</div><h2 style="font-size:18px">Ask AI · Study Group</h2></div></div>
    </div>
    <div style="align-self:flex-end;max-width:76%;background:linear-gradient(135deg,var(--violet),#9B7BFF);color:#fff;padding:12px 15px;border-radius:20px 20px 6px 20px;font-size:14px;font-weight:500;margin-left:auto;width:fit-content">Summarize our group chat</div>
    <div class="glass" style="margin-top:14px;border-radius:20px 20px 20px 6px">
      <div class="between" style="margin-bottom:12px"><p class="eyebrow">46 messages · last 3 hours</p><span class="pill on">AI summary</span></div>
      <div class="stack" style="gap:12px">
        ${[['The decision','Study session is Saturday 6 PM. Jordan books the room.','check','#35E1C8'],
           ['Still open','Nobody has picked the topic order yet — Rhea wants graphs first.','help','#FFB84D'],
           ['Expenses','₹1,200 pooled for printed notes. Rhea hasn\'t added hers yet.','wallet','#7C5CFC']].map(([t,d,i,c])=>
        `<div class="row" style="gap:11px;align-items:flex-start"><div class="sqico" style="background:${c}26;width:30px;height:30px;flex:0 0 30px;margin-top:1px">${ic(i,c,15,2.2)}</div>
        <div><div style="font-size:13px;font-weight:800">${t}</div><p class="p" style="font-size:12.5px;margin-top:3px">${d}</p></div></div>`).join('')}
      </div>
      <div class="hairline" style="margin:14px 0"></div>
      <p class="p" style="font-size:11.5px">AI-generated from messages in this group only — NEXORA never reads chats you aren't part of, and never posts as a participant.</p>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
      <button class="pill on" onclick="toast('Poll posted to the group.','poll','#7C5CFC')">Make a topic poll</button>
      <button class="pill" onclick="toast('Reminder sent to Rhea.','bell','#FFB84D')">Nudge Rhea</button>
      <button class="pill" onclick="go('group')">Post summary to group</button>
    </div>
    <h3 class="section-title">What else Ask AI can do here</h3>
    <div class="list">
      ${[['Find important messages','Flags decisions, times and anything addressed to you','flag','#FF6E7F'],
         ['Create a meeting plan','Turns "let\'s meet Saturday" into a time, place and list','cal','#7C5CFC'],
         ['Generate a to-do list','Splits tasks and reminds people','users','#FFB84D'],
         ['Explain something discussed','Breaks down a term or topic someone mentioned','help','#9B7BFF'],
         ['Organize group expenses','Splits a bill and tracks who\'s paid','wallet','#35E1C8']].map(([t,s,i,c])=>
      `<div class="item"><div class="sqico" style="background:${c}26">${ic(i,c,17,2.1)}</div><div class="col"><div class="t">${t}</div><div class="s" style="white-space:normal">${s}</div></div></div>`).join('')}
    </div>
    <h3 class="section-title">What's happening</h3>
    <div class="glass">
      <p class="p" style="font-size:12.5px">Campus, city and general news come from published sources — NEXORA links them instead of writing news itself.</p>
      <div class="stack" style="gap:9px;margin-top:12px">
        ${[['Cultural fest dates announced','Campus bulletin · 2 h ago'],['Metro line extension opens Monday','City news · 5 h ago'],['Internship drive: 12 firms in July','Placement cell · yesterday']].map(([t,s])=>
        `<div class="row" style="gap:10px;background:var(--glass2);padding:11px 12px;border-radius:14px"><div style="flex:1"><div style="font-size:12.5px;font-weight:700;line-height:1.35">${t}</div><div style="font-size:11px;color:var(--muted);font-weight:600;margin-top:3px">${s}</div></div>${ic('share','var(--muted)',15)}</div>`).join('')}
      </div>
    </div>
  </div>
</div>`);

/* =================== 33. Voice call =================== */
reg('call-voice','Chats','Voice Call',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column;background:radial-gradient(120% 90% at 30% 0%,#241B57,#0A0E1E 70%);color:#fff">
  ${statusbar()}
  <div class="body" style="color:#fff;display:flex;flex-direction:column;align-items:center;text-align:center;justify-content:space-between;padding-bottom:40px">
    <div style="padding-top:36px">
      <div style="position:relative;display:inline-block">
        ${[0,1].map(i=>`<div style="position:absolute;inset:${-14-i*14}px;border-radius:50%;border:1.5px solid rgba(255,255,255,.2);animation:ring2 2.6s ${i*.5}s infinite ease-out"></div>`).join('')}
        ${av('P','linear-gradient(135deg,#35E1C8,#7C5CFC)',126,46)}
      </div>
      <h2 style="font-family:var(--disp);font-size:27px;letter-spacing:-.015em;margin:26px 0 0;font-weight:700">Priya S</h2>
      <p style="font-size:14px;opacity:.7;margin:8px 0 0;font-variant-numeric:tabular-nums">04:12</p>
      <span class="pill" style="background:rgba(255,255,255,.12);color:#fff;margin-top:14px">${ic('lock','#fff',12,2.6)} End-to-end encrypted</span>
    </div>
    <div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin-bottom:26px">
        ${[['mic','Mute',0],['video','Video',0],['users','Add',0],['grid','Keypad',0],['phone','Speaker',1],['chat','Message',0]].map(([i,l,on])=>
        `<div style="text-align:center"><div style="width:62px;height:62px;border-radius:50%;background:${on?'#fff':'rgba(255,255,255,.12)'};display:grid;place-items:center;margin:0 auto">${ic(i,on?'#241B57':'#fff',24,2)}</div><div style="font-size:11px;opacity:.7;font-weight:600;margin-top:8px">${l}</div></div>`).join('')}
      </div>
      <button style="width:72px;height:72px;border-radius:50%;background:linear-gradient(135deg,#FF4D5E,#FF6E7F);display:grid;place-items:center;margin:0 auto" onclick="toast('Call ended · 4 min 18 s','phone','#FF6E7F');setTimeout(back,700)">
        <div style="transform:rotate(135deg)">${ic('phone','#fff',28,2.1)}</div>
      </button>
    </div>
    <style>@keyframes ring2{0%{transform:scale(.9);opacity:.6}100%{transform:scale(1.35);opacity:0}}</style>
  </div>
</div>`);

/* =================== 34. Video call =================== */
reg('call-video','Chats','Video Call',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column;background:#0A0E1E;color:#fff">
  <div style="position:absolute;inset:0;background:linear-gradient(150deg,#7C5CFC,#35E1C8 55%,#FF6E7F);opacity:.85"></div>
  <div style="position:absolute;inset:0;background:radial-gradient(60% 50% at 50% 38%, rgba(0,0,0,0), rgba(0,0,0,.45))"></div>
  ${statusbar()}
  <div style="position:absolute;top:60px;left:18px;right:18px;z-index:5" class="between">
    <span class="pill" style="background:rgba(0,0,0,.35);color:#fff">${ic('video','#fff',13,2.4)} Study Group · 3 on call</span>
    <span class="pill" style="background:rgba(0,0,0,.35);color:#fff;font-variant-numeric:tabular-nums">12:06</span>
  </div>
  <div style="position:absolute;top:50%;left:0;right:0;transform:translateY(-50%);text-align:center;z-index:5">
    ${av('P','rgba(255,255,255,.22)',108,40)}<h2 style="font-family:var(--disp);font-size:23px;letter-spacing:-.015em;margin:18px 0 0;font-weight:700">Priya is speaking</h2>
  </div>
  <div style="position:absolute;right:16px;top:110px;z-index:6;display:flex;flex-direction:column;gap:10px">
    ${[['J','#FFB84D'],['R','#FF6E7F']].map(([i,c])=>`<div style="width:78px;height:104px;border-radius:18px;background:${c};display:grid;place-items:center;border:2px solid rgba(255,255,255,.28)">${av(i,'rgba(255,255,255,.28)',40,15)}</div>`).join('')}
    <div style="width:78px;height:104px;border-radius:18px;background:linear-gradient(135deg,#7C5CFC,#9B7BFF);display:grid;place-items:center;border:2px solid #fff;position:relative">${av('A','rgba(255,255,255,.28)',40,15)}<span style="position:absolute;bottom:6px;font-size:9px;font-weight:800">You</span></div>
  </div>
  <div style="position:absolute;left:0;right:0;bottom:0;padding:18px 20px 36px;z-index:6;background:linear-gradient(transparent,rgba(0,0,0,.55) 40%)">
    <div class="row" style="gap:10px;justify-content:center">
      ${['mic','video','users','chat','grid'].map(i=>`<div style="width:54px;height:54px;border-radius:50%;background:rgba(255,255,255,.16);backdrop-filter:blur(10px);display:grid;place-items:center">${ic(i,'#fff',22,2)}</div>`).join('')}
      <div style="width:54px;height:54px;border-radius:50%;background:linear-gradient(135deg,#FF4D5E,#FF6E7F);display:grid;place-items:center" onclick="back()"><div style="transform:rotate(135deg)">${ic('phone','#fff',22,2.1)}</div></div>
    </div>
  </div>
</div>`);

/* =================== 35. Profile =================== */
reg('profile','Profile & Security','Profile',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Profile',{back:true,right:`<button class="iconbtn" onclick="go('settings')">${ic('cog','currentColor',18)}</button>`})}
    <div class="glass" style="text-align:center">
      <div style="position:relative;display:inline-block">
        ${av('A','linear-gradient(135deg,#7C5CFC,#35E1C8)',88,33)}
        <button class="iconbtn" style="position:absolute;bottom:-2px;right:-2px;width:30px;height:30px;border-radius:11px;background:linear-gradient(135deg,var(--violet),var(--cyan));border:0">${ic('cam','#fff',15,2.2)}</button>
      </div>
      <h2 style="font-family:var(--disp);font-size:22px;letter-spacing:-.015em;margin:14px 0 3px;font-weight:700">Alex Menon</h2>
      <p class="p" style="font-size:12.5px">@alexm · alex.m@college.edu</p>
      <div class="row" style="gap:7px;justify-content:center;margin-top:12px"><span class="pill cyan">${ic('check','#26C9AE',12,3)} Verified student</span><span class="pill">B.Tech CSE · 2027</span></div>
      <div class="row" style="gap:0;margin-top:20px;padding-top:16px;border-top:1px solid var(--hair)">
        ${[['24','Friends'],['58','Diary pages'],['312','Day streak']].map(([v,k],i)=>
        `<div style="flex:1;${i?'border-left:1px solid var(--hair)':''}"><div class="big" style="font-size:19px">${v}</div><div style="font-size:10.5px;color:var(--muted);font-weight:700;margin-top:4px">${k}</div></div>`).join('')}
      </div>
    </div>
    <div class="glass tight row" style="margin-top:12px;gap:11px" onclick="go('friendselect')">
      <div style="display:flex">${[['P','#35E1C8'],['J','#FFB84D'],['R','#FF6E7F'],['D','#7C5CFC']].map(([i,c],n)=>`<div style="margin-left:${n?'-11px':'0'};border:2.5px solid var(--bg);border-radius:50%">${av(i,c,32,12)}</div>`).join('')}</div>
      <div style="flex:1"><div style="font-size:13.5px;font-weight:800">24 friends</div><p class="p" style="font-size:11.5px">3 sharing location with you</p></div>${ic('chev','var(--muted)',17)}
    </div>
    <h3 class="section-title">Account</h3>
    <div class="list">
      ${[['Account activity','Recent logins and actions','user','#7C5CFC',''],
         ['Privacy & security','Password, Face ID, data controls','shield','#35E1C8','security'],
         ['Active login sessions','3 devices signed in','device','#9B7BFF','devices'],
         ['Location-sharing permissions','Who can see you, and for how long','pin','#FF6E7F','locperm'],
         ['Notification settings','What reaches you and when','bell','#FFB84D','settings'],
         ['Theme settings','Dark, light, and text size','paint','#7C5CFC','settings'],
         ['Help & support','Guides, contact, report a problem','help','#9691C4','helpcenter']].map(([t,s,i,c,to])=>
      `<div class="item" ${to?`onclick="go('${to}')"`:''}><div class="sqico" style="background:${c}26">${ic(i,c,17,2.1)}</div><div class="col"><div class="t">${t}</div><div class="s">${s}</div></div>${ic('chev','var(--muted)',16)}</div>`).join('')}
    </div>
    <button class="btn line" style="margin-top:16px;color:#FF6E7F;border-color:rgba(255,110,127,.35)" onclick="logoutConfirm()">${ic('logout','#FF6E7F',18)} Log out</button>
    <p class="p" style="text-align:center;font-size:11px;margin-top:14px">NEXORA 1.0 · Demo build for hackathon judging</p>
  </div>
</div>`);

/* =================== 36. Privacy & Security =================== */
reg('security','Profile & Security','Privacy & Security',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Privacy & security',{back:true})}
    <div class="glass" style="background:linear-gradient(135deg,#35E1C8,#57F0D8);border:0;color:#04241D">
      <div class="row" style="gap:12px">
        <div style="width:46px;height:46px;border-radius:16px;background:rgba(4,36,29,.14);display:grid;place-items:center">${ic('shield','#04241D',22,2.2)}</div>
        <div><div style="font-family:var(--disp);font-size:18px;letter-spacing:-.01em;font-weight:700">Your account is secure</div><p style="font-size:12px;font-weight:600;opacity:.7;margin:3px 0 0">Face ID on · 2FA on · no unknown sessions</p></div>
      </div>
    </div>
    <h3 class="section-title">Sign-in</h3>
    <div class="list">
      ${[['Face ID for NEXORA','Also unlocks your diary',1],['Two-factor authentication','Code sent to your email',1],['Save password securely','Stored by iOS, never shown in-app',1],['Alert me about new sign-ins','Like the one this morning',1]].map(([t,s,on])=>
      `<div class="item"><div class="col"><div class="t">${t}</div><div class="s" style="white-space:normal">${s}</div></div><div class="switch ${on?'on':''}" onclick="tog(this)"></div></div>`).join('')}
    </div>
    <div class="list" style="margin-top:12px">
      <div class="item" onclick="go('newlogin')"><div class="sqico" style="background:rgba(255,184,77,.2)">${ic('alert','#FFB84D',17,2.1)}</div><div class="col"><div class="t">Last new-device alert</div><div class="s">iPhone 15 Pro · this morning</div></div>${ic('chev','var(--muted)',16)}</div>
      <div class="item" onclick="go('forgot')"><div class="sqico" style="background:rgba(124,92,252,.2)">${ic('lock','var(--violet)',17,2.1)}</div><div class="col"><div class="t">Change password</div><div class="s">Last changed 3 months ago</div></div>${ic('chev','var(--muted)',16)}</div>
      <div class="item" onclick="go('devices')"><div class="sqico" style="background:rgba(155,123,255,.2)">${ic('device','#9B7BFF',17,2.1)}</div><div class="col"><div class="t">Active sessions</div><div class="s">3 devices</div></div>${ic('chev','var(--muted)',16)}</div>
    </div>
    <h3 class="section-title">What stays private</h3>
    <div class="list">
      ${[['Diary entries','Protected on-device. Never used to train anything.','book','#9B7BFF'],
         ['Mood check-ins','Visible only to you. Never shared with friends.','heart','#FF6E7F'],
         ['Location','Only during a track you consented to, only to people you picked.','pin','#35E1C8'],
         ['Money data','Prototype figures in this build. No bank is connected.','wallet','#FFB84D']].map(([t,s,i,c])=>
      `<div class="item"><div class="sqico" style="background:${c}26">${ic(i,c,17,2.1)}</div><div class="col"><div class="t">${t}</div><div class="s" style="white-space:normal">${s}</div></div></div>`).join('')}
    </div>
    <h3 class="section-title">Your data</h3>
    <div class="list">
      <div class="item" onclick="toast('Export started, we will email the file.','share','#7C5CFC')"><div class="col"><div class="t">Download my data</div><div class="s">Everything NEXORA holds, as a file</div></div>${ic('chev','var(--muted)',16)}</div>
      <div class="item" onclick="toast('AI personalisation paused.','spark','#9B7BFF')"><div class="col"><div class="t">Pause AI personalisation</div><div class="s">NEXORA will stop learning your patterns</div></div><div class="switch" onclick="tog(this)"></div></div>
      <div class="item" onclick="deleteAccountConfirm()"><div class="col"><div class="t" style="color:#FF6E7F">Delete account</div><div class="s">Removes everything, permanently</div></div>${ic('chev','var(--muted)',16)}</div>
    </div>
  </div>
</div>`);

/* =================== 37. Active devices =================== */
reg('devices','Profile & Security','Active Devices',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Devices & sessions',{back:true,sub:'Anything you don\'t recognise, sign it out.'})}
    <div class="glass" style="border:1.5px solid var(--cyan)">
      <div class="between"><span class="pill cyan">This device</span>${ic('device','var(--cyan)',18,2.1)}</div>
      <div style="font-family:var(--disp);font-size:17px;letter-spacing:-.01em;margin:11px 0 4px;font-weight:700">iPhone 15 Pro · Alex</div>
      <p class="p" style="font-size:12px">Chennai, Tamil Nadu · active now</p>
    </div>
    <h3 class="section-title">Other sessions</h3>
    <div class="stack">
      ${[['MacBook Air','Chrome · Chennai · 2 hours ago','device','#7C5CFC',0],
         ['iPad (hostel)','NEXORA app · Chennai · yesterday','device','#9B7BFF',0],
         ['Windows PC','Chrome · Bengaluru · today, 9:41 AM','alert','#FFB84D',1]].map(([n,s,i,c,sus])=>
      `<div class="glass tight row" style="gap:11px;${sus?'background:rgba(255,184,77,.1);border:0':''}">
        <div class="sqico" style="background:${c}26;width:40px;height:40px;flex:0 0 40px;border-radius:14px">${ic(i,c,18,2.1)}</div>
        <div style="flex:1"><div style="font-size:14px;font-weight:800">${n}</div><p class="p" style="font-size:11.5px;margin-top:2px">${s}</p>${sus?'<span class="pill amber" style="margin-top:7px">Unrecognised</span>':''}</div>
        <button class="pill" style="color:#FF6E7F" onclick="toast('${n} signed out.','check')">Sign out</button>
      </div>`).join('')}
    </div>
    <button class="btn line" style="margin-top:16px;color:#FF6E7F;border-color:rgba(255,110,127,.35)" onclick="signOutAllConfirm()">Sign out of all other sessions</button>
    <div class="glass" style="margin-top:16px;background:var(--glass2);border:0">
      <p class="p" style="font-size:12px">Locations are approximate, based on network address. Signing a device out doesn't reveal or change your password.</p>
    </div>
  </div>
</div>`);

/* =================== 39. Settings =================== */
reg('settings','Profile & Security','Settings',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Settings',{back:true})}
    <h3 class="section-title" style="margin-top:4px">Theme</h3>
    <div class="glass">
      <div class="row" style="gap:9px">
        ${[['Dark','#0A0E1E','#F3F1FF','dark'],['Light','#F3F1FC','#17163B','light']].map(([n,bg,fg,t],i)=>
        `<div style="flex:1;text-align:center;cursor:pointer" onclick="setTheme('${t}');paint()"><div style="height:70px;border-radius:16px;background:${bg};border:2.5px solid ${i===0?'var(--violet)':'var(--border)'};display:grid;place-items:center;color:${fg};font-size:11px;font-weight:800">Aa</div><div style="font-size:11px;font-weight:700;margin-top:7px;color:var(--muted)">${n}</div></div>`).join('')}
      </div>
      <div class="hairline" style="margin:16px 0 12px"></div>
      <div class="between" style="margin-bottom:9px"><span style="font-size:13px;font-weight:700">Text size</span><span class="pill">Default</span></div>
      <input type="range" min="1" max="5" value="3" style="width:100%;accent-color:var(--violet)">
    </div>
    <h3 class="section-title">Notifications</h3>
    <div class="list">
      ${[['Security alerts','New sign-ins and session changes',1],['Messages','Direct and group chats',1],['Location requests','When a friend wants to track',1],['Money alerts','Low balance, shared goals',1],['Diary reminders','A gentle nudge in the evening',1],['AI suggestions','Ideas based on your week',0]].map(([t,s,on])=>
      `<div class="item"><div class="col"><div class="t">${t}</div><div class="s">${s}</div></div><div class="switch ${on?'on':''}" onclick="tog(this)"></div></div>`).join('')}
    </div>
    <h3 class="section-title">App</h3>
    <div class="list">
      ${[['Language','English (India)'],['Currency','Indian Rupee (₹)'],['Reduce motion','Off'],['Storage','142 MB used']].map(([t,v])=>
      `<div class="item"><div class="col"><div class="t">${t}</div></div><span style="font-size:12.5px;color:var(--muted);font-weight:700">${v}</span>${ic('chev','var(--muted)',16)}</div>`).join('')}
    </div>
    <p class="p" style="text-align:center;font-size:11px;margin-top:16px">NEXORA 1.0 (build 104) · Terms · Privacy Notice</p>
  </div>
</div>`);

/* =================== Help & Support (from profile) =================== */
reg('helpcenter','Profile & Security','Help & Support Centre',()=>`
<div style="position:absolute;inset:0;display:flex;flex-direction:column">${mesh()}
  ${statusbar()}
  <div class="body">
    ${nav('Help & support',{back:true})}
    <div class="field">${ic('search','var(--muted)',18)}<input placeholder="Search help articles"></div>
    <div class="grid2" style="margin-top:14px">
      <button class="glass tight" style="text-align:left;background:linear-gradient(135deg,var(--violet),var(--cyan));border:0;color:#fff" onclick="toast('Connecting you to support…','chat','#7C5CFC')">
        <div class="sqico" style="background:rgba(255,255,255,.2)">${ic('chat','#fff',17,2.2)}</div>
        <div style="font-size:14px;font-weight:800;margin-top:10px">Chat with support</div><p style="font-size:11.5px;opacity:.85;margin:3px 0 0">Usually replies in 5 min</p>
      </button>
      <button class="glass tight" style="text-align:left" onclick="go('help')">
        <div class="sqico" style="background:rgba(255,184,77,.2)">${ic('alert','var(--amber)',17,2.2)}</div>
        <div style="font-size:14px;font-weight:800;margin-top:10px">Report a problem</div><p class="p" style="font-size:11.5px;margin-top:3px">Something broken or unsafe</p>
      </button>
    </div>
    <h3 class="section-title">Common questions</h3>
    <div class="list">
      ${[['Can anyone read my diary?','No — entries are protected on your device','book','#9B7BFF'],
         ['Who sees my location?','Only people you consented to, only during a track','pin','#35E1C8'],
         ['Is my money data real?','This build uses demo figures only','wallet','#FFB84D'],
         ['How does the AI use my data?','What it reads, and how to turn it off','spark','#7C5CFC'],
         ['I think someone accessed my account','Secure it in three steps','shield','#35E1C8']].map(([t,s,i,c])=>
      `<div class="item"><div class="sqico" style="background:${c}26">${ic(i,c,17,2.1)}</div><div class="col"><div class="t" style="white-space:normal">${t}</div><div class="s" style="white-space:normal">${s}</div></div>${ic('chev','var(--muted)',16)}</div>`).join('')}
    </div>
    <div class="glass" style="margin-top:16px;background:rgba(255,110,127,.1);border:0">
      <p class="p" style="font-size:12.5px;color:var(--text)">NEXORA isn't a counsellor. If you're struggling, a person helps more than an app can — see <b style="color:var(--coral)" onclick="go('helpline')">trusted support options</b>.</p>
    </div>
  </div>
</div>`);

// __MORE_SCREENS__

/* =================== boot =================== */
const GROUPS=['Onboarding','Home & AI','Stress Buster','Money Guard','Track Friends','My Diary','Chats','Profile & Security'];
function buildRail(){
  const byG={}; Object.values(S).forEach(s=>{(byG[s.group]=byG[s.group]||[]).push(s)});
  let n=0, html='';
  GROUPS.forEach(g=>{ if(!byG[g])return;
    html+=`<h2>${g}</h2>`+byG[g].map(s=>`<a data-id="${s.id}" onclick="stack=['${s.id}'];paint('anim')"><i>${String(++n).padStart(2,'0')}</i>${s.label}</a>`).join('');
  });
  $('#rail').innerHTML=html;
}
buildRail(); paint();
